const TOKEN_KEY = "hotel_iot_token";
const $ = id => document.getElementById(id);
const token = () => localStorage.getItem(TOKEN_KEY) || "";
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function api(path, method = "GET", body) {
    const res = await fetch(path, {
        method,
        headers: { "Content-Type": "application/json", "Authorization": token() },
        body: body ? JSON.stringify(body) : undefined
    });
    if (res.status === 401 && path !== "/api/login") { logout(true); throw new Error("Chua dang nhap"); }
    return res.json();
}

function checkAuthUI() {
    const btn = $("btnAuthToggle"), on = !!token();
    btn.innerText = on ? "Dang Xuat (Admin)" : "Dang Nhap Admin";
    btn.style.backgroundColor = on ? "#ef4444" : "#0284c7";
    btn.onclick = on ? () => logout() : openLoginModal;
}
const openLoginModal = () => $("loginModal").style.display = "flex";
const closeLoginModal = () => $("loginModal").style.display = "none";

async function handleLogin() {
    const username = $("loginUser").value.trim(), password = $("loginPass").value.trim();
    if (!username || !password) return alert("Vui long nhap day du tai khoan va mat khau!");
    try {
        const d = await api("/api/login", "POST", { username, password });
        if (d.status !== "success") return alert("Dang nhap that bai: " + (d.message || "Sai thong tin"));
        localStorage.setItem(TOKEN_KEY, d.token);
        closeLoginModal(); checkAuthUI(); loadAll();
    } catch { alert("Khong the ket noi may chu xac thuc!"); }
}

function logout(silent) {
    localStorage.removeItem(TOKEN_KEY);
    checkAuthUI();
    if (!silent) alert("Da dang xuat tai khoan.");
}

const TAB_LOADERS = { tabCards: () => loadCards(), tabLogs: () => loadLogs(), tabDeviceLogs: () => loadDeviceLogs(), tabEvents: () => loadEvents() };
function switchTab(evt, tabId) {
    document.querySelectorAll(".tab-btn, .tab-content").forEach(el => el.classList.remove("active"));
    evt?.currentTarget?.classList.add("active");
    $(tabId)?.classList.add("active");
    TAB_LOADERS[tabId]?.();
}

function setCard(id, text, cls, sub) {
    $("val" + id).innerText = text;
    $("val" + id).className = "card-value " + cls;
    if (sub !== undefined) $("sub" + id).innerText = sub;
}
const setDot = (id, ok, text) => { $("dot" + id).className = ok ? "status-dot" : "status-dot red"; $("text" + id).innerText = text; };

async function pollStatus() {
    try {
        const d = await (await fetch("/api/status")).json();
        const led = (d.led || "WHITE").toUpperCase();
        setCard("Door", d.door, d.door === "OPEN" ? "val-open" : "val-closed", d.door === "OPEN" ? "Cua phong dang mo" : "Chot cua dang khoa an toan");
        setCard("Roof", d.roof, d.roof === "OPEN" ? "val-open" : "val-amber", d.roof === "OPEN" ? "Mai che dang mo thoang khi" : "Mai che da dong che chan");
        setCard("Led", led, led === "OFF" ? "val-closed" : "val-white", led === "OFF" ? "Den LED phong da tat" : `Den LED phong dang sang (${led})`);
        setCard("Rain", d.rain ? "TROI DANG MUA" : "KHO RAO", d.rain ? "val-closed" : "val-cyan");
        $("badgeLed").innerText = led;
        $("subOled").innerText = "OLED: " + (d.oled || "");
        setDot("Sql", d.sql_connected, d.sql_connected ? "SQL Server: Online" : "SQL Server: Offline (Cache)");
        setDot("Pi", true, "RPI: Online");
    } catch {
        setDot("Pi", false, "RPI: Mat ket noi");
    }
}

async function sendCommand(command) {
    try {
        const d = await api("/api/control", "POST", { command, cmd_id: "WEB_" + Date.now() });
        if (d.status !== "success") alert("Lenh bi tu choi (dang mua thi khong mo duoc mai che)!");
        pollStatus(); loadDeviceLogs(); loadEvents();
    } catch (e) { alert("Khong gui duoc lenh: " + e.message); }
}

async function fillTable(tbodyId, path, cols, emptyText) {
    const tbody = $(tbodyId);
    if (!tbody || !token()) return;
    try {
        const rows = await api(path);
        tbody.innerHTML = rows.length
            ? rows.map(r => `<tr>${cols.map(c => `<td>${c(r)}</td>`).join("")}</tr>`).join("")
            : `<tr><td colspan="${cols.length}" style="text-align:center;">${emptyText}</td></tr>`;
    } catch {  }
}

const uidCell = v => `<span style="color: var(--accent-cyan); font-weight: 700;">${esc(v)}</span>`;
const badge = (ok, text) => `<span class="badge-status ${ok}">${esc(text)}</span>`;

function loadCards() {
    fillTable("tbodyCards", "/api/cards", [
        c => `<strong>${c.id}</strong>`,
        c => uidCell(c.uid),
        c => esc(c.holder),
        c => badge(c.active ? "badge-active" : "badge-inactive", c.active ? "Dang hoat dong" : "Da khoa"),
        c => `<button class="btn btn-blue" style="padding:4px 8px;font-size:11px;" data-uid="${esc(c.uid)}" onclick="toggleCard(this.dataset.uid, ${c.active})">${c.active ? "Khoa" : "Mo Khoa"}</button>
              <button class="btn btn-red" style="padding:4px 8px;font-size:11px;margin-left:6px;" data-uid="${esc(c.uid)}" onclick="deleteCard(this.dataset.uid)">Xoa</button>`
    ], "Chua co the nao trong co so du lieu.");
}

function loadLogs() {
    const q = new URLSearchParams({ uid: $("filterUid").value.trim(), status: $("filterStatus").value });
    fillTable("tbodyLogs", "/api/logs?" + q, [
        l => l.id, l => esc(l.time), l => uidCell(l.uid),
        l => badge(l.status === "ACCESS" ? "badge-access" : "badge-denied", l.status),
        l => esc(l.notes)
    ], "Khong tim thay lich su phu hop.");
}

function loadDeviceLogs() {
    fillTable("tbodyDeviceLogs", "/api/device-logs", [
        d => d.id, d => esc(d.time), d => `<strong style="color: var(--accent-cyan);">${esc(d.device)}</strong>`,
        d => `<span style="font-weight:700;color:${["OPEN", "ON"].includes(d.action) ? "#34d399" : "#f87171"}">${esc(d.action)}</span>`,
        d => `<span class="card-badge">${esc(d.source)}</span>`, d => esc(d.details)
    ], "Chua co du lieu lich su thiet bi.");
}

function loadEvents() {
    fillTable("tbodyEvents", "/api/events", [
        e => e.id, e => esc(e.time), e => `<strong>${esc(e.type)}</strong>`, e => esc(e.desc),
        e => `<span class="card-badge" style="color:${e.severity === "WARNING" ? "#f59e0b" : "#38bdf8"}">${esc(e.severity)}</span>`
    ], "Khong co su kien he thong.");
}

const loadAll = () => { loadCards(); loadLogs(); loadDeviceLogs(); loadEvents(); };

async function cardAction(method, path, body) {
    try {
        const d = await api(path, method, body);
        if (d.status !== "success") return alert(d.message || "Thao tac that bai");
        loadCards(); loadEvents();
        return true;
    } catch (e) { alert(e.message); }
}

async function addCard() {
    const uid = $("newCardUid").value.trim().toUpperCase(), holder = $("newCardHolder").value.trim();
    if (!uid || !holder) return alert("Vui long dien du Ma UID va Ten chu the!");
    if (await cardAction("POST", "/api/cards", { uid, holder })) {
        $("newCardUid").value = $("newCardHolder").value = "";
    }
}
const toggleCard = (uid, active) => cardAction("PUT", "/api/cards", { uid, active: !active });
const deleteCard = uid => confirm(`Xac nhan xoa hoan toan the UID: ${uid}?`) && cardAction("DELETE", "/api/cards?uid=" + encodeURIComponent(uid));

window.onload = () => {
    checkAuthUI();
    pollStatus();
    loadAll();
    setInterval(pollStatus, 2000);
};
