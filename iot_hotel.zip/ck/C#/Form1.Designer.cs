﻿namespace HotelAdminDesktop
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            pnlHeader = new Panel();
            pnlChannelBadge = new Panel();
            pnlStatusDot = new Panel();
            lblActiveChannel = new Label();
            lblTitle = new Label();
            lblTag = new Label();
            pnlConfigBar = new Panel();
            lblIp = new Label();
            txtIpAddress = new TextBox();
            btnConnectWifi = new Button();
            btnConnectBle = new Button();
            btnDisconnectBle = new Button();
            cardDoor = new Panel();
            btnCloseDoor = new Button();
            btnOpenDoor = new Button();
            lblDoorSub = new Label();
            lblDoorVal = new Label();
            lblDoorTitle = new Label();
            cardRoof = new Panel();
            btnCloseRoof = new Button();
            btnOpenRoof = new Button();
            lblRoofSub = new Label();
            lblRoofVal = new Label();
            lblRoofTitle = new Label();
            cardEnv = new Panel();
            btnLedOff = new Button();
            btnLedOn = new Button();
            lblOledVal = new Label();
            lblLedVal = new Label();
            lblLedTitle = new Label();
            lblRainVal = new Label();
            lblRainTitle = new Label();
            lblEnvTitle = new Label();
            cardSystem = new Panel();
            btnResetSystem = new Button();
            lblMqttVal = new Label();
            lblMqttTitle = new Label();
            lblSqlVal = new Label();
            lblSqlTitle = new Label();
            lblPiVal = new Label();
            lblPiTitle = new Label();
            lblSysTitle = new Label();
            tabControl = new TabControl();
            tabCards = new TabPage();
            dgvCards = new DataGridView();
            pnlCardActions = new Panel();
            txtNewUid = new TextBox();
            txtNewHolder = new TextBox();
            btnAddCard = new Button();
            btnToggleCard = new Button();
            btnDeleteCard = new Button();
            tabLogs = new TabPage();
            dgvLogs = new DataGridView();
            pnlLogFilter = new Panel();
            txtFilterUid = new TextBox();
            cboFilterStatus = new ComboBox();
            btnRefreshLogs = new Button();
            tabDeviceLogs = new TabPage();
            dgvDeviceLogs = new DataGridView();
            pnlDeviceLogActions = new Panel();
            btnRefreshDeviceLogs = new Button();
            tabEvents = new TabPage();
            dgvEvents = new DataGridView();
            pnlEventActions = new Panel();
            btnRefreshEvents = new Button();
            timerPoll = new System.Windows.Forms.Timer(components);
            tmrAnimation = new System.Windows.Forms.Timer(components);
            pnlHeader.SuspendLayout();
            pnlChannelBadge.SuspendLayout();
            pnlConfigBar.SuspendLayout();
            cardDoor.SuspendLayout();
            cardRoof.SuspendLayout();
            cardEnv.SuspendLayout();
            cardSystem.SuspendLayout();
            tabControl.SuspendLayout();
            tabCards.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvCards).BeginInit();
            pnlCardActions.SuspendLayout();
            tabLogs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvLogs).BeginInit();
            pnlLogFilter.SuspendLayout();
            tabDeviceLogs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDeviceLogs).BeginInit();
            pnlDeviceLogActions.SuspendLayout();
            tabEvents.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvEvents).BeginInit();
            pnlEventActions.SuspendLayout();
            SuspendLayout();
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.FromArgb(15, 23, 42);
            pnlHeader.Controls.Add(pnlChannelBadge);
            pnlHeader.Controls.Add(lblTitle);
            pnlHeader.Controls.Add(lblTag);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Margin = new Padding(4, 5, 4, 5);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(1657, 130);
            pnlHeader.TabIndex = 0;
            // 
            // pnlChannelBadge
            // 
            pnlChannelBadge.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pnlChannelBadge.BackColor = Color.FromArgb(30, 41, 59);
            pnlChannelBadge.Controls.Add(pnlStatusDot);
            pnlChannelBadge.Controls.Add(lblActiveChannel);
            pnlChannelBadge.Location = new Point(1264, 33);
            pnlChannelBadge.Margin = new Padding(4, 5, 4, 5);
            pnlChannelBadge.Name = "pnlChannelBadge";
            pnlChannelBadge.Size = new Size(357, 63);
            pnlChannelBadge.TabIndex = 2;
            // 
            // pnlStatusDot
            // 
            pnlStatusDot.BackColor = Color.FromArgb(16, 185, 129);
            pnlStatusDot.Location = new Point(20, 22);
            pnlStatusDot.Margin = new Padding(4, 5, 4, 5);
            pnlStatusDot.Name = "pnlStatusDot";
            pnlStatusDot.Size = new Size(17, 20);
            pnlStatusDot.TabIndex = 0;
            pnlStatusDot.Paint += pnlStatusDot_Paint;
            // 
            // lblActiveChannel
            // 
            lblActiveChannel.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            lblActiveChannel.ForeColor = Color.FromArgb(248, 250, 252);
            lblActiveChannel.Location = new Point(46, 0);
            lblActiveChannel.Margin = new Padding(4, 0, 4, 0);
            lblActiveChannel.Name = "lblActiveChannel";
            lblActiveChannel.Size = new Size(307, 63);
            lblActiveChannel.TabIndex = 1;
            lblActiveChannel.Text = "Wi-Fi: Đang kết nối...";
            lblActiveChannel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblTitle.ForeColor = Color.FromArgb(248, 250, 252);
            lblTitle.Location = new Point(31, 55);
            lblTitle.Margin = new Padding(4, 0, 4, 0);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(430, 45);
            lblTitle.TabIndex = 1;
            lblTitle.Text = "Bảng Quản Trị Ngoại Vi IoT";
            // 
            // lblTag
            // 
            lblTag.AutoSize = true;
            lblTag.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
            lblTag.ForeColor = Color.FromArgb(56, 189, 248);
            lblTag.Location = new Point(34, 23);
            lblTag.Margin = new Padding(4, 0, 4, 0);
            lblTag.Name = "lblTag";
            lblTag.Size = new Size(394, 23);
            lblTag.TabIndex = 0;
            lblTag.Text = "HOTEL SMART ROOM 101 • EDGE CONTROLLER";
            // 
            // pnlConfigBar
            // 
            pnlConfigBar.BackColor = Color.FromArgb(30, 41, 59);
            pnlConfigBar.Controls.Add(lblIp);
            pnlConfigBar.Controls.Add(txtIpAddress);
            pnlConfigBar.Controls.Add(btnConnectWifi);
            pnlConfigBar.Controls.Add(btnConnectBle);
            pnlConfigBar.Controls.Add(btnDisconnectBle);
            pnlConfigBar.Location = new Point(34, 158);
            pnlConfigBar.Margin = new Padding(4, 5, 4, 5);
            pnlConfigBar.Name = "pnlConfigBar";
            pnlConfigBar.Size = new Size(1587, 93);
            pnlConfigBar.TabIndex = 1;
            // 
            // lblIp
            // 
            lblIp.AutoSize = true;
            lblIp.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblIp.ForeColor = Color.FromArgb(148, 163, 184);
            lblIp.Location = new Point(23, 33);
            lblIp.Margin = new Padding(4, 0, 4, 0);
            lblIp.Name = "lblIp";
            lblIp.Size = new Size(142, 25);
            lblIp.TabIndex = 0;
            lblIp.Text = "IP RASPBERRY:";
            // 
            // txtIpAddress
            // 
            txtIpAddress.BackColor = Color.FromArgb(15, 23, 42);
            txtIpAddress.BorderStyle = BorderStyle.FixedSingle;
            txtIpAddress.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            txtIpAddress.ForeColor = Color.FromArgb(56, 189, 248);
            txtIpAddress.Location = new Point(164, 25);
            txtIpAddress.Margin = new Padding(4, 5, 4, 5);
            txtIpAddress.Name = "txtIpAddress";
            txtIpAddress.Size = new Size(242, 34);
            txtIpAddress.TabIndex = 1;
            txtIpAddress.Text = "192.168.127.93"; 
            txtIpAddress.TextAlign = HorizontalAlignment.Center;
            txtIpAddress.TextChanged += txtIpAddress_TextChanged;
            // 
            // btnConnectWifi
            // 
            btnConnectWifi.BackColor = Color.FromArgb(2, 132, 199);
            btnConnectWifi.FlatAppearance.BorderSize = 0;
            btnConnectWifi.FlatStyle = FlatStyle.Flat;
            btnConnectWifi.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnConnectWifi.ForeColor = Color.White;
            btnConnectWifi.Location = new Point(436, 20);
            btnConnectWifi.Margin = new Padding(4, 5, 4, 5);
            btnConnectWifi.Name = "btnConnectWifi";
            btnConnectWifi.Size = new Size(214, 53);
            btnConnectWifi.TabIndex = 2;
            btnConnectWifi.Text = "KẾT NỐI WI-FI / LAN";
            btnConnectWifi.UseVisualStyleBackColor = false;
            btnConnectWifi.Click += btnConnectWifi_Click;
            // 
            // btnConnectBle
            // 
            btnConnectBle.BackColor = Color.FromArgb(16, 185, 129);
            btnConnectBle.FlatAppearance.BorderSize = 0;
            btnConnectBle.FlatStyle = FlatStyle.Flat;
            btnConnectBle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnConnectBle.ForeColor = Color.White;
            btnConnectBle.Location = new Point(671, 20);
            btnConnectBle.Margin = new Padding(4, 5, 4, 5);
            btnConnectBle.Name = "btnConnectBle";
            btnConnectBle.Size = new Size(221, 53);
            btnConnectBle.TabIndex = 3;
            btnConnectBle.Text = "QUÉT & KẾT NỐI BLE";
            btnConnectBle.UseVisualStyleBackColor = false;
            btnConnectBle.Click += btnConnectBle_Click;
            // 
            // btnDisconnectBle
            // 
            btnDisconnectBle.BackColor = Color.FromArgb(71, 85, 105);
            btnDisconnectBle.FlatAppearance.BorderSize = 0;
            btnDisconnectBle.FlatStyle = FlatStyle.Flat;
            btnDisconnectBle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnDisconnectBle.ForeColor = Color.White;
            btnDisconnectBle.Location = new Point(914, 20);
            btnDisconnectBle.Margin = new Padding(4, 5, 4, 5);
            btnDisconnectBle.Name = "btnDisconnectBle";
            btnDisconnectBle.Size = new Size(157, 53);
            btnDisconnectBle.TabIndex = 4;
            btnDisconnectBle.Text = "NGẮT BLE";
            btnDisconnectBle.UseVisualStyleBackColor = false;
            btnDisconnectBle.Click += btnDisconnectBle_Click;
            // 
            // cardDoor
            // 
            cardDoor.BackColor = Color.FromArgb(30, 41, 59);
            cardDoor.Controls.Add(btnCloseDoor);
            cardDoor.Controls.Add(btnOpenDoor);
            cardDoor.Controls.Add(lblDoorSub);
            cardDoor.Controls.Add(lblDoorVal);
            cardDoor.Controls.Add(lblDoorTitle);
            cardDoor.Location = new Point(34, 280);
            cardDoor.Margin = new Padding(4, 5, 4, 5);
            cardDoor.Name = "cardDoor";
            cardDoor.Size = new Size(379, 342);
            cardDoor.TabIndex = 2;
            cardDoor.Paint += Card_Paint;
            cardDoor.MouseEnter += Card_MouseEnter;
            cardDoor.MouseLeave += Card_MouseLeave;
            // 
            // btnCloseDoor
            // 
            btnCloseDoor.BackColor = Color.FromArgb(239, 68, 68);
            btnCloseDoor.FlatAppearance.BorderSize = 0;
            btnCloseDoor.FlatStyle = FlatStyle.Flat;
            btnCloseDoor.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnCloseDoor.ForeColor = Color.White;
            btnCloseDoor.Location = new Point(196, 225);
            btnCloseDoor.Margin = new Padding(4, 5, 4, 5);
            btnCloseDoor.Name = "btnCloseDoor";
            btnCloseDoor.Size = new Size(160, 80);
            btnCloseDoor.TabIndex = 1;
            btnCloseDoor.Text = "ĐÓNG CỬA";
            btnCloseDoor.UseVisualStyleBackColor = false;
            btnCloseDoor.Click += btnCloseDoor_Click;
            // 
            // btnOpenDoor
            // 
            btnOpenDoor.BackColor = Color.FromArgb(16, 185, 129);
            btnOpenDoor.FlatAppearance.BorderSize = 0;
            btnOpenDoor.FlatStyle = FlatStyle.Flat;
            btnOpenDoor.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnOpenDoor.ForeColor = Color.White;
            btnOpenDoor.Location = new Point(23, 225);
            btnOpenDoor.Margin = new Padding(4, 5, 4, 5);
            btnOpenDoor.Name = "btnOpenDoor";
            btnOpenDoor.Size = new Size(160, 80);
            btnOpenDoor.TabIndex = 0;
            btnOpenDoor.Text = "MỞ CỬA";
            btnOpenDoor.UseVisualStyleBackColor = false;
            btnOpenDoor.Click += btnOpenDoor_Click;
            // 
            // lblDoorSub
            // 
            lblDoorSub.Font = new Font("Segoe UI", 9F);
            lblDoorSub.ForeColor = Color.FromArgb(100, 116, 139);
            lblDoorSub.Location = new Point(20, 157);
            lblDoorSub.Margin = new Padding(4, 0, 4, 0);
            lblDoorSub.Name = "lblDoorSub";
            lblDoorSub.Size = new Size(336, 33);
            lblDoorSub.TabIndex = 2;
            lblDoorSub.Text = "Chốt cửa đang khóa an toàn";
            lblDoorSub.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblDoorVal
            // 
            lblDoorVal.Font = new Font("Segoe UI", 26F, FontStyle.Bold);
            lblDoorVal.ForeColor = Color.FromArgb(239, 68, 68);
            lblDoorVal.Location = new Point(20, 67);
            lblDoorVal.Margin = new Padding(4, 0, 4, 0);
            lblDoorVal.Name = "lblDoorVal";
            lblDoorVal.Size = new Size(336, 80);
            lblDoorVal.TabIndex = 3;
            lblDoorVal.Text = "CLOSED";
            lblDoorVal.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblDoorTitle
            // 
            lblDoorTitle.AutoSize = true;
            lblDoorTitle.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
            lblDoorTitle.ForeColor = Color.FromArgb(148, 163, 184);
            lblDoorTitle.Location = new Point(23, 23);
            lblDoorTitle.Margin = new Padding(4, 0, 4, 0);
            lblDoorTitle.Name = "lblDoorTitle";
            lblDoorTitle.Size = new Size(198, 23);
            lblDoorTitle.TabIndex = 0;
            lblDoorTitle.Text = "CỬA PHÒNG • SERVO 1";
            // 
            // cardRoof
            // 
            cardRoof.BackColor = Color.FromArgb(30, 41, 59);
            cardRoof.Controls.Add(btnCloseRoof);
            cardRoof.Controls.Add(btnOpenRoof);
            cardRoof.Controls.Add(lblRoofSub);
            cardRoof.Controls.Add(lblRoofVal);
            cardRoof.Controls.Add(lblRoofTitle);
            cardRoof.Location = new Point(437, 280);
            cardRoof.Margin = new Padding(4, 5, 4, 5);
            cardRoof.Name = "cardRoof";
            cardRoof.Size = new Size(379, 342);
            cardRoof.TabIndex = 3;
            cardRoof.Paint += Card_Paint;
            cardRoof.MouseEnter += Card_MouseEnter;
            cardRoof.MouseLeave += Card_MouseLeave;
            // 
            // btnCloseRoof
            // 
            btnCloseRoof.BackColor = Color.FromArgb(71, 85, 105);
            btnCloseRoof.FlatAppearance.BorderSize = 0;
            btnCloseRoof.FlatStyle = FlatStyle.Flat;
            btnCloseRoof.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnCloseRoof.ForeColor = Color.White;
            btnCloseRoof.Location = new Point(196, 225);
            btnCloseRoof.Margin = new Padding(4, 5, 4, 5);
            btnCloseRoof.Name = "btnCloseRoof";
            btnCloseRoof.Size = new Size(160, 80);
            btnCloseRoof.TabIndex = 1;
            btnCloseRoof.Text = "ĐÓNG MÁI";
            btnCloseRoof.UseVisualStyleBackColor = false;
            btnCloseRoof.Click += btnCloseRoof_Click;
            // 
            // btnOpenRoof
            // 
            btnOpenRoof.BackColor = Color.FromArgb(37, 99, 235);
            btnOpenRoof.FlatAppearance.BorderSize = 0;
            btnOpenRoof.FlatStyle = FlatStyle.Flat;
            btnOpenRoof.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnOpenRoof.ForeColor = Color.White;
            btnOpenRoof.Location = new Point(23, 225);
            btnOpenRoof.Margin = new Padding(4, 5, 4, 5);
            btnOpenRoof.Name = "btnOpenRoof";
            btnOpenRoof.Size = new Size(160, 80);
            btnOpenRoof.TabIndex = 0;
            btnOpenRoof.Text = "MỞ MÁI";
            btnOpenRoof.UseVisualStyleBackColor = false;
            btnOpenRoof.Click += btnOpenRoof_Click;
            // 
            // lblRoofSub
            // 
            lblRoofSub.Font = new Font("Segoe UI", 9F);
            lblRoofSub.ForeColor = Color.FromArgb(100, 116, 139);
            lblRoofSub.Location = new Point(20, 157);
            lblRoofSub.Margin = new Padding(4, 0, 4, 0);
            lblRoofSub.Name = "lblRoofSub";
            lblRoofSub.Size = new Size(336, 33);
            lblRoofSub.TabIndex = 2;
            lblRoofSub.Text = "Mái che đang mở thoáng";
            lblRoofSub.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblRoofVal
            // 
            lblRoofVal.Font = new Font("Segoe UI", 26F, FontStyle.Bold);
            lblRoofVal.ForeColor = Color.FromArgb(16, 185, 129);
            lblRoofVal.Location = new Point(20, 67);
            lblRoofVal.Margin = new Padding(4, 0, 4, 0);
            lblRoofVal.Name = "lblRoofVal";
            lblRoofVal.Size = new Size(336, 80);
            lblRoofVal.TabIndex = 3;
            lblRoofVal.Text = "OPEN";
            lblRoofVal.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblRoofTitle
            // 
            lblRoofTitle.AutoSize = true;
            lblRoofTitle.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
            lblRoofTitle.ForeColor = Color.FromArgb(148, 163, 184);
            lblRoofTitle.Location = new Point(23, 23);
            lblRoofTitle.Margin = new Padding(4, 0, 4, 0);
            lblRoofTitle.Name = "lblRoofTitle";
            lblRoofTitle.Size = new Size(167, 23);
            lblRoofTitle.TabIndex = 0;
            lblRoofTitle.Text = "MÁI CHE • SERVO 2";
            // 
            // cardEnv
            // 
            cardEnv.BackColor = Color.FromArgb(30, 41, 59);
            cardEnv.Controls.Add(btnLedOff);
            cardEnv.Controls.Add(btnLedOn);
            cardEnv.Controls.Add(lblOledVal);
            cardEnv.Controls.Add(lblLedVal);
            cardEnv.Controls.Add(lblLedTitle);
            cardEnv.Controls.Add(lblRainVal);
            cardEnv.Controls.Add(lblRainTitle);
            cardEnv.Controls.Add(lblEnvTitle);
            cardEnv.Location = new Point(840, 280);
            cardEnv.Margin = new Padding(4, 5, 4, 5);
            cardEnv.Name = "cardEnv";
            cardEnv.Size = new Size(379, 342);
            cardEnv.TabIndex = 4;
            cardEnv.Paint += Card_Paint;
            cardEnv.MouseEnter += Card_MouseEnter;
            cardEnv.MouseLeave += Card_MouseLeave;
            // 
            // btnLedOff
            // 
            btnLedOff.BackColor = Color.FromArgb(71, 85, 105);
            btnLedOff.FlatAppearance.BorderSize = 0;
            btnLedOff.FlatStyle = FlatStyle.Flat;
            btnLedOff.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnLedOff.ForeColor = Color.White;
            btnLedOff.Location = new Point(196, 200);
            btnLedOff.Margin = new Padding(4, 5, 4, 5);
            btnLedOff.Name = "btnLedOff";
            btnLedOff.Size = new Size(160, 60);
            btnLedOff.TabIndex = 1;
            btnLedOff.Text = "⚫ TẮT LED";
            btnLedOff.UseVisualStyleBackColor = false;
            btnLedOff.Click += btnLedOff_Click;
            // 
            // btnLedOn
            // 
            btnLedOn.BackColor = Color.FromArgb(245, 158, 11);
            btnLedOn.FlatAppearance.BorderSize = 0;
            btnLedOn.FlatStyle = FlatStyle.Flat;
            btnLedOn.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnLedOn.ForeColor = Color.White;
            btnLedOn.Location = new Point(23, 200);
            btnLedOn.Margin = new Padding(4, 5, 4, 5);
            btnLedOn.Name = "btnLedOn";
            btnLedOn.Size = new Size(160, 60);
            btnLedOn.TabIndex = 0;
            btnLedOn.Text = "💡 BẬT LED";
            btnLedOn.UseVisualStyleBackColor = false;
            btnLedOn.Click += btnLedOn_Click;
            // 
            // lblOledVal
            // 
            lblOledVal.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
            lblOledVal.ForeColor = Color.FromArgb(56, 189, 248);
            lblOledVal.Location = new Point(23, 280);
            lblOledVal.Margin = new Padding(4, 0, 4, 0);
            lblOledVal.Name = "lblOledVal";
            lblOledVal.Size = new Size(336, 33);
            lblOledVal.TabIndex = 2;
            lblOledVal.Text = "OLED: HOTEL IoT | OK";
            // 
            // lblLedVal
            // 
            lblLedVal.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            lblLedVal.ForeColor = Color.White;
            lblLedVal.Location = new Point(23, 153);
            lblLedVal.Margin = new Padding(4, 0, 4, 0);
            lblLedVal.Name = "lblLedVal";
            lblLedVal.Size = new Size(336, 30);
            lblLedVal.TabIndex = 3;
            lblLedVal.Text = "WHITE (SÁNG)";
            // 
            // lblLedTitle
            // 
            lblLedTitle.AutoSize = true;
            lblLedTitle.Font = new Font("Segoe UI", 8.5F);
            lblLedTitle.ForeColor = Color.FromArgb(148, 163, 184);
            lblLedTitle.Location = new Point(23, 125);
            lblLedTitle.Margin = new Padding(4, 0, 4, 0);
            lblLedTitle.Name = "lblLedTitle";
            lblLedTitle.Size = new Size(125, 23);
            lblLedTitle.TabIndex = 2;
            lblLedTitle.Text = "Trạng thái LED:";
            // 
            // lblRainVal
            // 
            lblRainVal.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            lblRainVal.ForeColor = Color.FromArgb(56, 189, 248);
            lblRainVal.Location = new Point(23, 87);
            lblRainVal.Margin = new Padding(4, 0, 4, 0);
            lblRainVal.Name = "lblRainVal";
            lblRainVal.Size = new Size(336, 30);
            lblRainVal.TabIndex = 4;
            lblRainVal.Text = "Khô ráo (Không mưa)";
            // 
            // lblRainTitle
            // 
            lblRainTitle.AutoSize = true;
            lblRainTitle.Font = new Font("Segoe UI", 8.5F);
            lblRainTitle.ForeColor = Color.FromArgb(148, 163, 184);
            lblRainTitle.Location = new Point(23, 60);
            lblRainTitle.Margin = new Padding(4, 0, 4, 0);
            lblRainTitle.Name = "lblRainTitle";
            lblRainTitle.Size = new Size(126, 23);
            lblRainTitle.TabIndex = 1;
            lblRainTitle.Text = "Cảm biến mưa:";
            // 
            // lblEnvTitle
            // 
            lblEnvTitle.AutoSize = true;
            lblEnvTitle.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
            lblEnvTitle.ForeColor = Color.FromArgb(148, 163, 184);
            lblEnvTitle.Location = new Point(23, 20);
            lblEnvTitle.Margin = new Padding(4, 0, 4, 0);
            lblEnvTitle.Name = "lblEnvTitle";
            lblEnvTitle.Size = new Size(273, 23);
            lblEnvTitle.TabIndex = 0;
            lblEnvTitle.Text = "MÔI TRƯỜNG & ĐÈN CHIẾU SÁNG";
            // 
            // cardSystem
            // 
            cardSystem.BackColor = Color.FromArgb(30, 41, 59);
            cardSystem.Controls.Add(btnResetSystem);
            cardSystem.Controls.Add(lblMqttVal);
            cardSystem.Controls.Add(lblMqttTitle);
            cardSystem.Controls.Add(lblSqlVal);
            cardSystem.Controls.Add(lblSqlTitle);
            cardSystem.Controls.Add(lblPiVal);
            cardSystem.Controls.Add(lblPiTitle);
            cardSystem.Controls.Add(lblSysTitle);
            cardSystem.Location = new Point(1243, 280);
            cardSystem.Margin = new Padding(4, 5, 4, 5);
            cardSystem.Name = "cardSystem";
            cardSystem.Size = new Size(379, 342);
            cardSystem.TabIndex = 5;
            cardSystem.Paint += Card_Paint;
            cardSystem.MouseEnter += Card_MouseEnter;
            cardSystem.MouseLeave += Card_MouseLeave;
            // 
            // btnResetSystem
            // 
            btnResetSystem.BackColor = Color.FromArgb(220, 38, 38);
            btnResetSystem.FlatAppearance.BorderSize = 0;
            btnResetSystem.FlatStyle = FlatStyle.Flat;
            btnResetSystem.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnResetSystem.ForeColor = Color.White;
            btnResetSystem.Location = new Point(23, 242);
            btnResetSystem.Margin = new Padding(4, 5, 4, 5);
            btnResetSystem.Name = "btnResetSystem";
            btnResetSystem.Size = new Size(333, 75);
            btnResetSystem.TabIndex = 4;
            btnResetSystem.Text = "🔄 RESET HỆ THỐNG";
            btnResetSystem.UseVisualStyleBackColor = false;
            btnResetSystem.Click += btnResetSystem_Click;
            // 
            // lblMqttVal
            // 
            lblMqttVal.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            lblMqttVal.ForeColor = Color.FromArgb(56, 189, 248);
            lblMqttVal.Location = new Point(23, 192);
            lblMqttVal.Margin = new Padding(4, 0, 4, 0);
            lblMqttVal.Name = "lblMqttVal";
            lblMqttVal.Size = new Size(336, 30);
            lblMqttVal.TabIndex = 5;
            lblMqttVal.Text = "PORT 10364 (LISTENING)";
            // 
            // lblMqttTitle
            // 
            lblMqttTitle.AutoSize = true;
            lblMqttTitle.Font = new Font("Segoe UI", 8F);
            lblMqttTitle.ForeColor = Color.FromArgb(148, 163, 184);
            lblMqttTitle.Location = new Point(23, 167);
            lblMqttTitle.Margin = new Padding(4, 0, 4, 0);
            lblMqttTitle.Name = "lblMqttTitle";
            lblMqttTitle.Size = new Size(193, 21);
            lblMqttTitle.TabIndex = 3;
            lblMqttTitle.Text = "Mosquitto Broker (10364):";
            // 
            // lblSqlVal
            // 
            lblSqlVal.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            lblSqlVal.ForeColor = Color.FromArgb(16, 185, 129);
            lblSqlVal.Location = new Point(23, 132);
            lblSqlVal.Margin = new Padding(4, 0, 4, 0);
            lblSqlVal.Name = "lblSqlVal";
            lblSqlVal.Size = new Size(336, 30);
            lblSqlVal.TabIndex = 6;
            lblSqlVal.Text = "CONNECTED";
            // 
            // lblSqlTitle
            // 
            lblSqlTitle.AutoSize = true;
            lblSqlTitle.Font = new Font("Segoe UI", 8F);
            lblSqlTitle.ForeColor = Color.FromArgb(148, 163, 184);
            lblSqlTitle.Location = new Point(23, 108);
            lblSqlTitle.Margin = new Padding(4, 0, 4, 0);
            lblSqlTitle.Name = "lblSqlTitle";
            lblSqlTitle.Size = new Size(150, 21);
            lblSqlTitle.TabIndex = 2;
            lblSqlTitle.Text = "SQL Server (14333):";
            // 
            // lblPiVal
            // 
            lblPiVal.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            lblPiVal.ForeColor = Color.FromArgb(16, 185, 129);
            lblPiVal.Location = new Point(23, 73);
            lblPiVal.Margin = new Padding(4, 0, 4, 0);
            lblPiVal.Name = "lblPiVal";
            lblPiVal.Size = new Size(336, 30);
            lblPiVal.TabIndex = 7;
            lblPiVal.Text = "RPI_ROOM_101 (ONLINE)";
            // 
            // lblPiTitle
            // 
            lblPiTitle.AutoSize = true;
            lblPiTitle.Font = new Font("Segoe UI", 8F);
            lblPiTitle.ForeColor = Color.FromArgb(148, 163, 184);
            lblPiTitle.Location = new Point(23, 50);
            lblPiTitle.Margin = new Padding(4, 0, 4, 0);
            lblPiTitle.Name = "lblPiTitle";
            lblPiTitle.Size = new Size(138, 21);
            lblPiTitle.TabIndex = 1;
            lblPiTitle.Text = "Raspberry Pi 3B+: ";
            // 
            // lblSysTitle
            // 
            lblSysTitle.AutoSize = true;
            lblSysTitle.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
            lblSysTitle.ForeColor = Color.FromArgb(148, 163, 184);
            lblSysTitle.Location = new Point(23, 17);
            lblSysTitle.Margin = new Padding(4, 0, 4, 0);
            lblSysTitle.Name = "lblSysTitle";
            lblSysTitle.Size = new Size(180, 23);
            lblSysTitle.TabIndex = 0;
            lblSysTitle.Text = "HẠ TẦNG HỆ THỐNG";
            // 
            // tabControl
            // 
            tabControl.Controls.Add(tabCards);
            tabControl.Controls.Add(tabLogs);
            tabControl.Controls.Add(tabDeviceLogs);
            tabControl.Controls.Add(tabEvents);
            tabControl.Font = new Font("Segoe UI", 9.5F);
            tabControl.Location = new Point(34, 650);
            tabControl.Margin = new Padding(4, 5, 4, 5);
            tabControl.Name = "tabControl";
            tabControl.SelectedIndex = 0;
            tabControl.Size = new Size(1587, 558);
            tabControl.TabIndex = 6;
            // 
            // tabCards
            // 
            tabCards.BackColor = Color.FromArgb(30, 41, 59);
            tabCards.Controls.Add(dgvCards);
            tabCards.Controls.Add(pnlCardActions);
            tabCards.Location = new Point(4, 34);
            tabCards.Margin = new Padding(4, 5, 4, 5);
            tabCards.Name = "tabCards";
            tabCards.Padding = new Padding(14, 17, 14, 17);
            tabCards.Size = new Size(1579, 520);
            tabCards.TabIndex = 0;
            tabCards.Text = "  Danh Sách Thẻ RFID (Bảng RFIDCards)  ";
            // 
            // dgvCards
            // 
            dgvCards.AllowUserToAddRows = false;
            dgvCards.AllowUserToDeleteRows = false;
            dgvCards.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvCards.BackgroundColor = Color.FromArgb(15, 23, 42);
            dgvCards.BorderStyle = BorderStyle.None;
            dgvCards.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCards.Dock = DockStyle.Fill;
            dgvCards.Location = new Point(14, 17);
            dgvCards.Margin = new Padding(4, 5, 4, 5);
            dgvCards.Name = "dgvCards";
            dgvCards.ReadOnly = true;
            dgvCards.RowHeadersVisible = false;
            dgvCards.RowHeadersWidth = 62;
            dgvCards.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCards.Size = new Size(1551, 403);
            dgvCards.TabIndex = 0;
            // 
            // pnlCardActions
            // 
            pnlCardActions.BackColor = Color.FromArgb(30, 41, 59);
            pnlCardActions.Controls.Add(txtNewUid);
            pnlCardActions.Controls.Add(txtNewHolder);
            pnlCardActions.Controls.Add(btnAddCard);
            pnlCardActions.Controls.Add(btnToggleCard);
            pnlCardActions.Controls.Add(btnDeleteCard);
            pnlCardActions.Dock = DockStyle.Bottom;
            pnlCardActions.Location = new Point(14, 420);
            pnlCardActions.Margin = new Padding(4, 5, 4, 5);
            pnlCardActions.Name = "pnlCardActions";
            pnlCardActions.Size = new Size(1551, 83);
            pnlCardActions.TabIndex = 1;
            // 
            // txtNewUid
            // 
            txtNewUid.BackColor = Color.FromArgb(15, 23, 42);
            txtNewUid.BorderStyle = BorderStyle.FixedSingle;
            txtNewUid.Font = new Font("Segoe UI", 9.5F);
            txtNewUid.ForeColor = Color.FromArgb(56, 189, 248);
            txtNewUid.Location = new Point(14, 23);
            txtNewUid.Margin = new Padding(4, 5, 4, 5);
            txtNewUid.Name = "txtNewUid";
            txtNewUid.PlaceholderText = "Mã UID thẻ (VD: 1B EA D8 99 B)";
            txtNewUid.Size = new Size(285, 33);
            txtNewUid.TabIndex = 0;
            // 
            // txtNewHolder
            // 
            txtNewHolder.BackColor = Color.FromArgb(15, 23, 42);
            txtNewHolder.BorderStyle = BorderStyle.FixedSingle;
            txtNewHolder.Font = new Font("Segoe UI", 9.5F);
            txtNewHolder.ForeColor = Color.White;
            txtNewHolder.Location = new Point(314, 23);
            txtNewHolder.Margin = new Padding(4, 5, 4, 5);
            txtNewHolder.Name = "txtNewHolder";
            txtNewHolder.PlaceholderText = "Tên khách lưu trú / Số phòng";
            txtNewHolder.Size = new Size(313, 33);
            txtNewHolder.TabIndex = 1;
            // 
            // btnAddCard
            // 
            btnAddCard.BackColor = Color.FromArgb(16, 185, 129);
            btnAddCard.FlatAppearance.BorderSize = 0;
            btnAddCard.FlatStyle = FlatStyle.Flat;
            btnAddCard.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnAddCard.ForeColor = Color.White;
            btnAddCard.Location = new Point(650, 18);
            btnAddCard.Margin = new Padding(4, 5, 4, 5);
            btnAddCard.Name = "btnAddCard";
            btnAddCard.Size = new Size(171, 50);
            btnAddCard.TabIndex = 2;
            btnAddCard.Text = "+ THÊM THẺ";
            btnAddCard.UseVisualStyleBackColor = false;
            btnAddCard.Click += btnAddCard_Click;
            // 
            // btnToggleCard
            // 
            btnToggleCard.BackColor = Color.FromArgb(2, 132, 199);
            btnToggleCard.FlatAppearance.BorderSize = 0;
            btnToggleCard.FlatStyle = FlatStyle.Flat;
            btnToggleCard.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnToggleCard.ForeColor = Color.White;
            btnToggleCard.Location = new Point(836, 18);
            btnToggleCard.Margin = new Padding(4, 5, 4, 5);
            btnToggleCard.Name = "btnToggleCard";
            btnToggleCard.Size = new Size(186, 50);
            btnToggleCard.TabIndex = 3;
            btnToggleCard.Text = "KHÓA / MỞ THẺ";
            btnToggleCard.UseVisualStyleBackColor = false;
            btnToggleCard.Click += btnToggleCard_Click;
            // 
            // btnDeleteCard
            // 
            btnDeleteCard.BackColor = Color.FromArgb(239, 68, 68);
            btnDeleteCard.FlatAppearance.BorderSize = 0;
            btnDeleteCard.FlatStyle = FlatStyle.Flat;
            btnDeleteCard.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnDeleteCard.ForeColor = Color.White;
            btnDeleteCard.Location = new Point(1036, 18);
            btnDeleteCard.Margin = new Padding(4, 5, 4, 5);
            btnDeleteCard.Name = "btnDeleteCard";
            btnDeleteCard.Size = new Size(143, 50);
            btnDeleteCard.TabIndex = 4;
            btnDeleteCard.Text = "XÓA THẺ";
            btnDeleteCard.UseVisualStyleBackColor = false;
            btnDeleteCard.Click += btnDeleteCard_Click;
            // 
            // tabLogs
            // 
            tabLogs.BackColor = Color.FromArgb(30, 41, 59);
            tabLogs.Controls.Add(dgvLogs);
            tabLogs.Controls.Add(pnlLogFilter);
            tabLogs.Location = new Point(4, 34);
            tabLogs.Margin = new Padding(4, 5, 4, 5);
            tabLogs.Name = "tabLogs";
            tabLogs.Padding = new Padding(14, 17, 14, 17);
            tabLogs.Size = new Size(1579, 520);
            tabLogs.TabIndex = 1;
            tabLogs.Text = "  Lịch Sử Quét Thẻ (Bảng RFIDLogs)  ";
            // 
            // dgvLogs
            // 
            dgvLogs.AllowUserToAddRows = false;
            dgvLogs.AllowUserToDeleteRows = false;
            dgvLogs.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvLogs.BackgroundColor = Color.FromArgb(15, 23, 42);
            dgvLogs.BorderStyle = BorderStyle.None;
            dgvLogs.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvLogs.Dock = DockStyle.Fill;
            dgvLogs.Location = new Point(14, 92);
            dgvLogs.Margin = new Padding(4, 5, 4, 5);
            dgvLogs.Name = "dgvLogs";
            dgvLogs.ReadOnly = true;
            dgvLogs.RowHeadersVisible = false;
            dgvLogs.RowHeadersWidth = 62;
            dgvLogs.Size = new Size(1551, 411);
            dgvLogs.TabIndex = 0;
            // 
            // pnlLogFilter
            // 
            pnlLogFilter.BackColor = Color.FromArgb(30, 41, 59);
            pnlLogFilter.Controls.Add(txtFilterUid);
            pnlLogFilter.Controls.Add(cboFilterStatus);
            pnlLogFilter.Controls.Add(btnRefreshLogs);
            pnlLogFilter.Dock = DockStyle.Top;
            pnlLogFilter.Location = new Point(14, 17);
            pnlLogFilter.Margin = new Padding(4, 5, 4, 5);
            pnlLogFilter.Name = "pnlLogFilter";
            pnlLogFilter.Size = new Size(1551, 75);
            pnlLogFilter.TabIndex = 1;
            // 
            // txtFilterUid
            // 
            txtFilterUid.BackColor = Color.FromArgb(15, 23, 42);
            txtFilterUid.BorderStyle = BorderStyle.FixedSingle;
            txtFilterUid.Font = new Font("Segoe UI", 9.5F);
            txtFilterUid.ForeColor = Color.FromArgb(56, 189, 248);
            txtFilterUid.Location = new Point(14, 17);
            txtFilterUid.Margin = new Padding(4, 5, 4, 5);
            txtFilterUid.Name = "txtFilterUid";
            txtFilterUid.PlaceholderText = "Lọc theo mã UID...";
            txtFilterUid.Size = new Size(285, 33);
            txtFilterUid.TabIndex = 0;
            txtFilterUid.TextChanged += txtFilterUid_TextChanged;
            // 
            // cboFilterStatus
            // 
            cboFilterStatus.BackColor = Color.FromArgb(15, 23, 42);
            cboFilterStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cboFilterStatus.FlatStyle = FlatStyle.Flat;
            cboFilterStatus.Font = new Font("Segoe UI", 9.5F);
            cboFilterStatus.ForeColor = Color.White;
            cboFilterStatus.Items.AddRange(new object[] { "-- Tất cả trạng thái --", "ACCESS", "DENIED" });
            cboFilterStatus.Location = new Point(321, 17);
            cboFilterStatus.Margin = new Padding(4, 5, 4, 5);
            cboFilterStatus.Name = "cboFilterStatus";
            cboFilterStatus.Size = new Size(227, 33);
            cboFilterStatus.TabIndex = 1;
            cboFilterStatus.SelectedIndexChanged += cboFilterStatus_SelectedIndexChanged;
            // 
            // btnRefreshLogs
            // 
            btnRefreshLogs.BackColor = Color.FromArgb(2, 132, 199);
            btnRefreshLogs.FlatAppearance.BorderSize = 0;
            btnRefreshLogs.FlatStyle = FlatStyle.Flat;
            btnRefreshLogs.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnRefreshLogs.ForeColor = Color.White;
            btnRefreshLogs.Location = new Point(571, 13);
            btnRefreshLogs.Margin = new Padding(4, 5, 4, 5);
            btnRefreshLogs.Name = "btnRefreshLogs";
            btnRefreshLogs.Size = new Size(171, 47);
            btnRefreshLogs.TabIndex = 2;
            btnRefreshLogs.Text = "LÀM MỚI";
            btnRefreshLogs.UseVisualStyleBackColor = false;
            btnRefreshLogs.Click += btnRefreshLogs_Click;
            // 
            // tabDeviceLogs
            // 
            tabDeviceLogs.BackColor = Color.FromArgb(30, 41, 59);
            tabDeviceLogs.Controls.Add(dgvDeviceLogs);
            tabDeviceLogs.Controls.Add(pnlDeviceLogActions);
            tabDeviceLogs.Location = new Point(4, 34);
            tabDeviceLogs.Margin = new Padding(4, 5, 4, 5);
            tabDeviceLogs.Name = "tabDeviceLogs";
            tabDeviceLogs.Padding = new Padding(14, 17, 14, 17);
            tabDeviceLogs.Size = new Size(1579, 520);
            tabDeviceLogs.TabIndex = 2;
            tabDeviceLogs.Text = "  Lịch Sử Thiết Bị (2 Servo & LED)  ";
            // 
            // dgvDeviceLogs
            // 
            dgvDeviceLogs.AllowUserToAddRows = false;
            dgvDeviceLogs.AllowUserToDeleteRows = false;
            dgvDeviceLogs.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvDeviceLogs.BackgroundColor = Color.FromArgb(15, 23, 42);
            dgvDeviceLogs.BorderStyle = BorderStyle.None;
            dgvDeviceLogs.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDeviceLogs.Dock = DockStyle.Fill;
            dgvDeviceLogs.Location = new Point(14, 87);
            dgvDeviceLogs.Margin = new Padding(4, 5, 4, 5);
            dgvDeviceLogs.Name = "dgvDeviceLogs";
            dgvDeviceLogs.ReadOnly = true;
            dgvDeviceLogs.RowHeadersVisible = false;
            dgvDeviceLogs.RowHeadersWidth = 62;
            dgvDeviceLogs.Size = new Size(1551, 416);
            dgvDeviceLogs.TabIndex = 0;
            // 
            // pnlDeviceLogActions
            // 
            pnlDeviceLogActions.BackColor = Color.FromArgb(30, 41, 59);
            pnlDeviceLogActions.Controls.Add(btnRefreshDeviceLogs);
            pnlDeviceLogActions.Dock = DockStyle.Top;
            pnlDeviceLogActions.Location = new Point(14, 17);
            pnlDeviceLogActions.Margin = new Padding(4, 5, 4, 5);
            pnlDeviceLogActions.Name = "pnlDeviceLogActions";
            pnlDeviceLogActions.Size = new Size(1551, 70);
            pnlDeviceLogActions.TabIndex = 1;
            // 
            // btnRefreshDeviceLogs
            // 
            btnRefreshDeviceLogs.BackColor = Color.FromArgb(2, 132, 199);
            btnRefreshDeviceLogs.FlatAppearance.BorderSize = 0;
            btnRefreshDeviceLogs.FlatStyle = FlatStyle.Flat;
            btnRefreshDeviceLogs.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnRefreshDeviceLogs.ForeColor = Color.White;
            btnRefreshDeviceLogs.Location = new Point(14, 10);
            btnRefreshDeviceLogs.Margin = new Padding(4, 5, 4, 5);
            btnRefreshDeviceLogs.Name = "btnRefreshDeviceLogs";
            btnRefreshDeviceLogs.Size = new Size(229, 47);
            btnRefreshDeviceLogs.TabIndex = 0;
            btnRefreshDeviceLogs.Text = "LÀM MỚI LỊCH SỬ";
            btnRefreshDeviceLogs.UseVisualStyleBackColor = false;
            btnRefreshDeviceLogs.Click += btnRefreshDeviceLogs_Click;
            // 
            // tabEvents
            // 
            tabEvents.BackColor = Color.FromArgb(30, 41, 59);
            tabEvents.Controls.Add(dgvEvents);
            tabEvents.Controls.Add(pnlEventActions);
            tabEvents.Location = new Point(4, 34);
            tabEvents.Margin = new Padding(4, 5, 4, 5);
            tabEvents.Name = "tabEvents";
            tabEvents.Padding = new Padding(14, 17, 14, 17);
            tabEvents.Size = new Size(1579, 520);
            tabEvents.TabIndex = 3;
            tabEvents.Text = "  Sự Kiện Hệ Thống (Bảng SystemEvents)  ";
            // 
            // dgvEvents
            // 
            dgvEvents.AllowUserToAddRows = false;
            dgvEvents.AllowUserToDeleteRows = false;
            dgvEvents.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvEvents.BackgroundColor = Color.FromArgb(15, 23, 42);
            dgvEvents.BorderStyle = BorderStyle.None;
            dgvEvents.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEvents.Dock = DockStyle.Fill;
            dgvEvents.Location = new Point(14, 87);
            dgvEvents.Margin = new Padding(4, 5, 4, 5);
            dgvEvents.Name = "dgvEvents";
            dgvEvents.ReadOnly = true;
            dgvEvents.RowHeadersVisible = false;
            dgvEvents.RowHeadersWidth = 62;
            dgvEvents.Size = new Size(1551, 416);
            dgvEvents.TabIndex = 0;
            // 
            // pnlEventActions
            // 
            pnlEventActions.BackColor = Color.FromArgb(30, 41, 59);
            pnlEventActions.Controls.Add(btnRefreshEvents);
            pnlEventActions.Dock = DockStyle.Top;
            pnlEventActions.Location = new Point(14, 17);
            pnlEventActions.Margin = new Padding(4, 5, 4, 5);
            pnlEventActions.Name = "pnlEventActions";
            pnlEventActions.Size = new Size(1551, 70);
            pnlEventActions.TabIndex = 1;
            // 
            // btnRefreshEvents
            // 
            btnRefreshEvents.BackColor = Color.FromArgb(2, 132, 199);
            btnRefreshEvents.FlatAppearance.BorderSize = 0;
            btnRefreshEvents.FlatStyle = FlatStyle.Flat;
            btnRefreshEvents.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnRefreshEvents.ForeColor = Color.White;
            btnRefreshEvents.Location = new Point(14, 10);
            btnRefreshEvents.Margin = new Padding(4, 5, 4, 5);
            btnRefreshEvents.Name = "btnRefreshEvents";
            btnRefreshEvents.Size = new Size(200, 47);
            btnRefreshEvents.TabIndex = 0;
            btnRefreshEvents.Text = "LÀM MỚI SỰ KIỆN";
            btnRefreshEvents.UseVisualStyleBackColor = false;
            btnRefreshEvents.Click += btnRefreshEvents_Click;
            // 
            // timerPoll
            // 
            timerPoll.Interval = 2000;
            timerPoll.Tick += timerPoll_Tick;
            // 
            // tmrAnimation
            // 
            tmrAnimation.Interval = 40;
            tmrAnimation.Tick += tmrAnimation_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(11, 17, 32);
            ClientSize = new Size(1657, 1242);
            Controls.Add(tabControl);
            Controls.Add(cardSystem);
            Controls.Add(cardEnv);
            Controls.Add(cardRoof);
            Controls.Add(cardDoor);
            Controls.Add(pnlConfigBar);
            Controls.Add(pnlHeader);
            Font = new Font("Segoe UI", 9F);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(4, 5, 4, 5);
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Hệ thống Quản trị Khách sạn IoT (Raspberry Pi 3B+ Edge Controller)";
            FormClosing += Form1_FormClosing;
            Load += Form1_Load;
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            pnlChannelBadge.ResumeLayout(false);
            pnlConfigBar.ResumeLayout(false);
            pnlConfigBar.PerformLayout();
            cardDoor.ResumeLayout(false);
            cardDoor.PerformLayout();
            cardRoof.ResumeLayout(false);
            cardRoof.PerformLayout();
            cardEnv.ResumeLayout(false);
            cardEnv.PerformLayout();
            cardSystem.ResumeLayout(false);
            cardSystem.PerformLayout();
            tabControl.ResumeLayout(false);
            tabCards.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvCards).EndInit();
            pnlCardActions.ResumeLayout(false);
            pnlCardActions.PerformLayout();
            tabLogs.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvLogs).EndInit();
            pnlLogFilter.ResumeLayout(false);
            pnlLogFilter.PerformLayout();
            tabDeviceLogs.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvDeviceLogs).EndInit();
            pnlDeviceLogActions.ResumeLayout(false);
            tabEvents.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvEvents).EndInit();
            pnlEventActions.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblTag;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnlChannelBadge;
        private System.Windows.Forms.Panel pnlStatusDot;
        private System.Windows.Forms.Label lblActiveChannel;
        private System.Windows.Forms.Panel pnlConfigBar;
        private System.Windows.Forms.Label lblIp;
        private System.Windows.Forms.TextBox txtIpAddress;
        private System.Windows.Forms.Button btnConnectWifi;
        private System.Windows.Forms.Button btnConnectBle;
        private System.Windows.Forms.Button btnDisconnectBle;
        private System.Windows.Forms.Panel cardDoor;
        private System.Windows.Forms.Label lblDoorTitle;
        private System.Windows.Forms.Label lblDoorVal;
        private System.Windows.Forms.Label lblDoorSub;
        private System.Windows.Forms.Button btnOpenDoor;
        private System.Windows.Forms.Button btnCloseDoor;
        private System.Windows.Forms.Panel cardRoof;
        private System.Windows.Forms.Label lblRoofTitle;
        private System.Windows.Forms.Label lblRoofVal;
        private System.Windows.Forms.Label lblRoofSub;
        private System.Windows.Forms.Button btnOpenRoof;
        private System.Windows.Forms.Button btnCloseRoof;
        private System.Windows.Forms.Panel cardEnv;
        private System.Windows.Forms.Label lblEnvTitle;
        private System.Windows.Forms.Label lblRainTitle;
        private System.Windows.Forms.Label lblRainVal;
        private System.Windows.Forms.Label lblLedTitle;
        private System.Windows.Forms.Label lblLedVal;
        private System.Windows.Forms.Button btnLedOn;
        private System.Windows.Forms.Button btnLedOff;
        private System.Windows.Forms.Label lblOledVal;
        private System.Windows.Forms.Panel cardSystem;
        private System.Windows.Forms.Label lblSysTitle;
        private System.Windows.Forms.Label lblPiTitle;
        private System.Windows.Forms.Label lblPiVal;
        private System.Windows.Forms.Label lblSqlTitle;
        private System.Windows.Forms.Label lblSqlVal;
        private System.Windows.Forms.Label lblMqttTitle;
        private System.Windows.Forms.Label lblMqttVal;
        private System.Windows.Forms.Button btnResetSystem;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabCards;
        private System.Windows.Forms.DataGridView dgvCards;
        private System.Windows.Forms.Panel pnlCardActions;
        private System.Windows.Forms.TextBox txtNewUid;
        private System.Windows.Forms.TextBox txtNewHolder;
        private System.Windows.Forms.Button btnAddCard;
        private System.Windows.Forms.Button btnToggleCard;
        private System.Windows.Forms.Button btnDeleteCard;
        private System.Windows.Forms.TabPage tabLogs;
        private System.Windows.Forms.DataGridView dgvLogs;
        private System.Windows.Forms.Panel pnlLogFilter;
        private System.Windows.Forms.TextBox txtFilterUid;
        private System.Windows.Forms.ComboBox cboFilterStatus;
        private System.Windows.Forms.Button btnRefreshLogs;
        private System.Windows.Forms.TabPage tabDeviceLogs;
        private System.Windows.Forms.DataGridView dgvDeviceLogs;
        private System.Windows.Forms.Panel pnlDeviceLogActions;
        private System.Windows.Forms.Button btnRefreshDeviceLogs;
        private System.Windows.Forms.TabPage tabEvents;
        private System.Windows.Forms.DataGridView dgvEvents;
        private System.Windows.Forms.Panel pnlEventActions;
        private System.Windows.Forms.Button btnRefreshEvents;
        private System.Windows.Forms.Timer timerPoll;
        private System.Windows.Forms.Timer tmrAnimation;
    }
}