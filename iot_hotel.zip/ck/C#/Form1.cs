using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.Advertisement;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Storage.Streams;
using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Client.Options;
using Panel = System.Windows.Forms.Panel;

namespace HotelAdminDesktop
{
    public partial class Form1 : Form
    {
        private const string AuthToken = "Bearer HotelIoTToken2026";
        private static readonly Guid ServiceUuid = new Guid("0000ffe0-0000-1000-8000-00805f9b34fb");
        private static readonly Guid CharStatusUuid = new Guid("0000ffe1-0000-1000-8000-00805f9b34fb");
        private static readonly Guid CharCmdUuid = new Guid("0000ffe2-0000-1000-8000-00805f9b34fb");

        private const int MqttPort = 10364;
        private const string TopicSubStatus = "hotel/room101/status";
        private const string TopicPubCmd = "hotel/room101/command";

        private static readonly Color CGreen = Color.FromArgb(16, 185, 129), CRed = Color.FromArgb(239, 68, 68),
            CAmber = Color.FromArgb(245, 158, 11), CCyan = Color.FromArgb(56, 189, 248),
            CGray = Color.FromArgb(148, 163, 184), CBg = Color.FromArgb(15, 23, 42), CLine = Color.FromArgb(51, 65, 85);

        private readonly HttpClient _http = new HttpClient { Timeout = TimeSpan.FromSeconds(5) };
        private string _baseUrl = "http://192.168.127.93:5000";
        private BluetoothLEDevice _bleDevice;
        private GattCharacteristic _statusChar, _cmdChar;
        private bool _isBleMode, _isUpdating;

        private IMqttClient _mqttClient;
        private IMqttClientOptions _mqttOptions;

        private double _pulseAngle;
        private Color _dotColor = CGreen;
        private Panel _hoveredCard;

        public Form1()
        {
            InitializeComponent();
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SetupGrid(dgvCards, ("id", "ID"), ("uid", "Ma UID The"), ("holder", "Mo ta / Chu phong"), ("active", "Trang thai the"));
            SetupGrid(dgvLogs, ("id", "Ma Log"), ("time", "Thoi gian quet"), ("uid", "Ma UID"), ("status", "Ket qua"), ("notes", "Ghi chu"));
            SetupGrid(dgvDeviceLogs, ("id", "ID"), ("time", "Thoi gian"), ("device", "Thiet bi"), ("action", "Hanh dong"),
                      ("source", "Nguon kich hoat"), ("details", "Mo ta chi tiet"));
            SetupGrid(dgvEvents, ("id", "ID"), ("time", "Thoi gian"), ("type", "Loai su kien"), ("desc", "Mo ta chi tiet"), ("severity", "Muc do"));
            cboFilterStatus.SelectedIndex = 0;
            tmrAnimation.Start();
            btnConnectWifi_Click(this, EventArgs.Empty);
        }

        private async void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            tmrAnimation.Stop();
            timerPoll.Stop();
            btnDisconnectBle_Click(this, EventArgs.Empty);

            if (_mqttClient != null && _mqttClient.IsConnected)
            {
                try { await _mqttClient.DisconnectAsync(); } catch { }
                _mqttClient.Dispose();
            }

            _http.Dispose();
        }

        private void tmrAnimation_Tick(object sender, EventArgs e)
        {
            _pulseAngle = (_pulseAngle + 0.12) % (2 * Math.PI);
            pnlStatusDot.Invalidate();
        }

        private void pnlStatusDot_Paint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            int alpha = (int)(162 + 92 * Math.Sin(_pulseAngle)) / 3;
            int w = Math.Max(pnlStatusDot.Width, 6), h = Math.Max(pnlStatusDot.Height, 6);
            using (var halo = new SolidBrush(Color.FromArgb(alpha, _dotColor))) g.FillEllipse(halo, 0, 0, w - 1, h - 1);
            using (var core = new SolidBrush(_dotColor)) g.FillEllipse(core, 2, 2, w - 5, h - 5);
        }

        private void Card_MouseEnter(object sender, EventArgs e) { _hoveredCard = sender as Panel; _hoveredCard?.Invalidate(); }
        private void Card_MouseLeave(object sender, EventArgs e) { _hoveredCard = null; (sender as Panel)?.Invalidate(); }

        private void Card_Paint(object sender, PaintEventArgs e)
        {
            if (sender is not Panel card) return;
            bool hover = card == _hoveredCard;
            using var pen = new Pen(hover ? CCyan : CLine, hover ? 2f : 1f);
            int o = hover ? 1 : 0;
            e.Graphics.DrawRectangle(pen, o, o, card.Width - 1 - 2 * o, card.Height - 1 - 2 * o);
        }

        private static void SetupGrid(DataGridView dgv, params (string name, string header)[] cols)
        {
            dgv.EnableHeadersVisualStyles = false;
            dgv.BackgroundColor = CBg;
            dgv.GridColor = CLine;
            dgv.BorderStyle = BorderStyle.None;
            dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.ColumnHeadersHeight = 36;
            dgv.RowTemplate.Height = 32;
            var head = dgv.ColumnHeadersDefaultCellStyle;
            head.BackColor = Color.FromArgb(30, 41, 59); head.ForeColor = CCyan;
            head.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold); head.Padding = new Padding(6);
            var cell = dgv.DefaultCellStyle;
            cell.BackColor = CBg; cell.ForeColor = Color.FromArgb(248, 250, 252); cell.Font = new Font("Segoe UI", 9F);
            cell.SelectionBackColor = CCyan; cell.SelectionForeColor = Color.FromArgb(11, 17, 32); cell.Padding = new Padding(4);
            dgv.Columns.Clear();
            foreach (var (name, header) in cols) dgv.Columns.Add(name, header);
        }

        private static void Info(string m) => MessageBox.Show(m, "Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private static void Warn(string m) => MessageBox.Show(m, "Canh bao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        private static void Error(string m) => MessageBox.Show(m, "Loi", MessageBoxButtons.OK, MessageBoxIcon.Error);

        private void SetChannel(string text, Color color)
        {
            lblActiveChannel.Text = text;
            _dotColor = color;
            pnlStatusDot.Invalidate();
        }

        private void ShowStatus(bool? doorOpen = null, bool? roofOpen = null, bool? rain = null, string led = null)
        {
            if (doorOpen is bool d)
            {
                lblDoorVal.Text = d ? "OPEN" : "CLOSED";
                lblDoorVal.ForeColor = d ? CGreen : CRed;
                lblDoorSub.Text = d ? "Cua dang mo" : "Chot cua dang khoa an toan";
            }
            if (roofOpen is bool r)
            {
                lblRoofVal.Text = r ? "OPEN" : "CLOSED";
                lblRoofVal.ForeColor = r ? CGreen : CAmber;
                lblRoofSub.Text = r ? "Mai che dang mo thoang" : "Mai che da dong che chan";
            }
            if (rain is bool w)
            {
                lblRainVal.Text = w ? "RAIN YES (Co mua)" : "Kho rao (Khong mua)";
                lblRainVal.ForeColor = w ? CRed : CCyan;
            }
            if (led != null)
            {
                lblLedVal.Text = led + (led == "OFF" ? " (DA TAT)" : " (DANG SANG)");
                lblLedVal.ForeColor = led == "OFF" ? CGray : Color.White;
            }
        }

        // ==================== TÍCH HỢP MQTT (MOSQUITTO CỔNG 10364) ====================
        private async Task InitMqttAsync(string ip)
        {
            try
            {
                if (_mqttClient != null)
                {
                    if (_mqttClient.IsConnected) await _mqttClient.DisconnectAsync();
                    _mqttClient.Dispose();
                }

                var factory = new MqttFactory();
                _mqttClient = factory.CreateMqttClient();

                _mqttOptions = new MqttClientOptionsBuilder()
                    .WithTcpServer(ip, MqttPort)
                    .WithClientId("CSharp_HotelAdmin_" + Guid.NewGuid().ToString().Substring(0, 5))
                    .WithCleanSession()
                    .Build();

                _mqttClient.UseApplicationMessageReceivedHandler(e =>
                {
                    try
                    {
                        string payload = Encoding.UTF8.GetString(e.ApplicationMessage.Payload);
                        var j = JObject.Parse(payload);
                        BeginInvoke(new Action(() =>
                        {
                            ShowStatus(
                                (string)j["door"] == "OPEN",
                                (string)j["roof"] == "OPEN",
                                (bool?)j["rain"] ?? false,
                                (string)j["led"] ?? "WHITE"
                            );
                            if (j["oled"] != null) lblOledVal.Text = "OLED: " + j["oled"];
                            bool sql = (bool?)j["sql_connected"] ?? false;
                            lblSqlVal.Text = sql ? "CONNECTED" : "OFFLINE (Local Cache)";
                            lblSqlVal.ForeColor = sql ? CGreen : CAmber;
                            lblPiVal.Text = j.Value<string>("device_id") + " (ONLINE)";
                            lblPiVal.ForeColor = CGreen;
                        }));
                    }
                    catch { }
                });

                await _mqttClient.ConnectAsync(_mqttOptions);
                await _mqttClient.SubscribeAsync(new MqttTopicFilterBuilder().WithTopic(TopicSubStatus).Build());
            }
            catch { }
        }

        private async Task<JToken> ApiAsync(HttpMethod method, string path, object body = null)
        {
            using var req = new HttpRequestMessage(method, _baseUrl + path);
            req.Headers.Add("Authorization", AuthToken);
            if (body != null)
                req.Content = new StringContent(JsonConvert.SerializeObject(body), Encoding.UTF8, "application/json");
            using var res = await _http.SendAsync(req);
            string text = await res.Content.ReadAsStringAsync();
            if (!res.IsSuccessStatusCode) throw new HttpRequestException($"Pi phan hoi {(int)res.StatusCode}: {text}");
            return JToken.Parse(text);
        }

        private async Task FillGridAsync(DataGridView dgv, string path)
        {
            if (_isBleMode) return;
            try
            {
                var arr = (JArray)await ApiAsync(HttpMethod.Get, path);
                var keys = dgv.Columns.Cast<DataGridViewColumn>().Select(c => c.Name).ToArray();
                dgv.Rows.Clear();
                foreach (var o in arr)
                    dgv.Rows.Add(keys.Select(k => o[k]?.Type == JTokenType.Boolean
                        ? ((bool)o[k] ? "Dang hoat dong" : "Da vo hieu hoa")
                        : (object)o[k]?.ToString()).ToArray());
            }
            catch { }
        }

        private Task RefreshCardsAsync() => FillGridAsync(dgvCards, "/api/cards");
        private Task RefreshDeviceLogsAsync() => FillGridAsync(dgvDeviceLogs, "/api/device-logs");
        private Task RefreshEventsAsync() => FillGridAsync(dgvEvents, "/api/events");
        private Task RefreshLogsAsync()
        {
            string status = cboFilterStatus.SelectedIndex > 0 ? cboFilterStatus.SelectedItem.ToString() : "";
            return FillGridAsync(dgvLogs, $"/api/logs?uid={Uri.EscapeDataString(txtFilterUid.Text.Trim())}&status={Uri.EscapeDataString(status)}");
        }

        private async Task RefreshAllAsync()
        {
            await RefreshCardsAsync(); await RefreshLogsAsync(); await RefreshDeviceLogsAsync(); await RefreshEventsAsync();
        }

        private async Task<bool> FetchStatusViaWifiAsync()
        {
            try
            {
                var j = await ApiAsync(HttpMethod.Get, "/api/status");
                ShowStatus((string)j["door"] == "OPEN", (string)j["roof"] == "OPEN", (bool?)j["rain"] ?? false, (string)j["led"] ?? "WHITE");
                lblOledVal.Text = "OLED: " + j["oled"];
                bool sql = (bool?)j["sql_connected"] ?? false;
                lblSqlVal.Text = sql ? "CONNECTED" : "OFFLINE (Local Cache)";
                lblSqlVal.ForeColor = sql ? CGreen : CAmber;
                lblPiVal.Text = j.Value<string>("device_id") + " (ONLINE)";
                lblPiVal.ForeColor = CGreen;
                return true;
            }
            catch { return false; }
        }

        private async void btnConnectWifi_Click(object sender, EventArgs e)
        {
            string ip = txtIpAddress.Text.Trim();
            if (ip.Length == 0) { Warn("Vui long nhap dia chi IP Raspberry Pi!"); return; }
            _baseUrl = $"http://{ip}:5000";
            _isBleMode = false;
            SetChannel("Dang ket noi Wi-Fi / MQTT...", CAmber);

            await InitMqttAsync(ip);

            await PollOnceAsync();
            timerPoll.Start();
            if (!_isBleMode) await RefreshAllAsync();
        }

        private async void timerPoll_Tick(object sender, EventArgs e) => await PollOnceAsync();

        private async Task PollOnceAsync()
        {
            if (_isUpdating) return;
            _isUpdating = true;
            try
            {
                bool wasBle = _isBleMode;
                if (await FetchStatusViaWifiAsync())
                {
                    _isBleMode = false;
                    bool mqttOk = _mqttClient != null && _mqttClient.IsConnected;
                    string channelMsg = mqttOk
                        ? $"Wi-Fi + MQTT: CONNECTED ({txtIpAddress.Text.Trim()}:{MqttPort})"
                        : $"Wi-Fi: CONNECTED ({txtIpAddress.Text.Trim()})";
                    SetChannel(channelMsg, CGreen);
                    if (wasBle) await RefreshAllAsync();
                }
                else if (_cmdChar != null)
                {
                    _isBleMode = true;
                    SetChannel("Kenh: BLE GATT (Du phong)", CCyan);
                }
                else
                {
                    SetChannel("Wi-Fi: DISCONNECTED", CRed);
                    lblPiVal.Text = "RPI (OFFLINE)";
                    lblPiVal.ForeColor = CRed;
                }
            }
            finally { _isUpdating = false; }
        }

        private async void btnConnectBle_Click(object sender, EventArgs e)
        {
            SetChannel("Dang quet BLE...", CAmber);
            btnConnectBle.Enabled = false;
            try
            {
                _bleDevice = await ScanBleDeviceAsync(TimeSpan.FromSeconds(6));
                if (_bleDevice == null) throw new Exception("Khong tim thay 'Khachsan_TuanHuy'. Kiem tra main.py tren Pi va Bluetooth cua may tinh.");

                var svc = await _bleDevice.GetGattServicesForUuidAsync(ServiceUuid, BluetoothCacheMode.Uncached);
                if (svc.Status != GattCommunicationStatus.Success || svc.Services.Count == 0)
                    throw new Exception($"Khong tim thay Service GATT: {svc.Status}");
                var chars = await svc.Services[0].GetCharacteristicsAsync(BluetoothCacheMode.Uncached);
                if (chars.Status != GattCommunicationStatus.Success)
                    throw new Exception($"Khong lay duoc Characteristic: {chars.Status}");

                _cmdChar = chars.Characteristics.FirstOrDefault(c => c.Uuid == CharCmdUuid);
                _statusChar = chars.Characteristics.FirstOrDefault(c => c.Uuid == CharStatusUuid);
                if (_statusChar != null)
                {
                    await _statusChar.WriteClientCharacteristicConfigurationDescriptorAsync(GattClientCharacteristicConfigurationDescriptorValue.Notify);
                    _statusChar.ValueChanged += StatusChar_ValueChanged;
                }
                SetChannel("Kenh: BLE GATT (Da ket noi)", CCyan);
                Info("Ghep noi BLE (Khachsan_TuanHuy) thanh cong!");
            }
            catch (Exception ex)
            {
                Error("Loi BLE: " + ex.Message);
                SetChannel("BLE: Loi ket noi", CRed);
            }
            finally { btnConnectBle.Enabled = true; }
        }

        private static async Task<BluetoothLEDevice> ScanBleDeviceAsync(TimeSpan timeout)
        {
            var tcs = new TaskCompletionSource<ulong>();
            var watcher = new BluetoothLEAdvertisementWatcher { ScanningMode = BluetoothLEScanningMode.Active };
            watcher.Received += (w, a) =>
            {
                string name = a.Advertisement.LocalName ?? "";
                if (name.Contains("TuanHuy", StringComparison.OrdinalIgnoreCase) || a.Advertisement.ServiceUuids.Contains(ServiceUuid))
                    tcs.TrySetResult(a.BluetoothAddress);
            };
            watcher.Start();
            bool found = await Task.WhenAny(tcs.Task, Task.Delay(timeout)) == tcs.Task;
            watcher.Stop();
            return found ? await BluetoothLEDevice.FromBluetoothAddressAsync(tcs.Task.Result) : null;
        }

        private void btnDisconnectBle_Click(object sender, EventArgs e)
        {
            if (_statusChar != null) _statusChar.ValueChanged -= StatusChar_ValueChanged;
            _statusChar = _cmdChar = null;
            _bleDevice?.Dispose();
            _bleDevice = null;
            _isBleMode = false;
            SetChannel("BLE: Da ngat ket noi", Color.FromArgb(100, 116, 139));
        }

        private void StatusChar_ValueChanged(GattCharacteristic sender, GattValueChangedEventArgs args)
        {
            var reader = DataReader.FromBuffer(args.CharacteristicValue);
            string raw = reader.ReadString(reader.UnconsumedBufferLength);
            var kv = raw.Split(',').Select(p => p.Split(':')).Where(p => p.Length == 2).ToDictionary(p => p[0], p => p[1] == "1");
            BeginInvoke(new Action(() => ShowStatus(
                kv.TryGetValue("D", out var d) ? d : null,
                kv.TryGetValue("R", out var r) ? r : null,
                kv.TryGetValue("W", out var w) ? w : null)));
        }

        // ==================== ĐIỀU KHIỂN THIẾT BỊ ====================
        private async Task SendCommandAsync(string command)
        {
            if (!_isBleMode)
            {
                // Ưu tiên 1: Gửi lệnh qua MQTT (phản hồi siêu tốc, dưới 15ms)
                if (_mqttClient != null && _mqttClient.IsConnected)
                {
                    try
                    {
                        var msg = new MqttApplicationMessageBuilder()
                            .WithTopic(TopicPubCmd)
                            .WithPayload(command)
                            .WithExactlyOnceQoS()
                            .Build();
                        await _mqttClient.PublishAsync(msg);
                        return; // Gửi xong thoát ngay, không gửi lặp qua HTTP
                    }
                    catch { }
                }

                // Ưu tiên 2: Fallback qua HTTP API nếu MQTT chưa kết nối
                try
                {
                    var res = await ApiAsync(HttpMethod.Post, "/api/control",
                        new { command, cmd_id = "CSHARP_" + DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() });
                    if ((string)res["status"] != "success") Warn($"Pi tu choi lenh {command}.");
                    return;
                }
                catch (HttpRequestException ex) when (ex.Message.StartsWith("Pi phan hoi")) { Error(ex.Message); return; }
                catch { await PollOnceAsync(); }
            }

            // Ưu tiên 3: Dự phòng qua BLE GATT
            if (_cmdChar == null) { Warn("Mat ca Wi-Fi va BLE! Khong the gui lenh."); return; }
            try
            {
                var writer = new DataWriter();
                writer.WriteString(command);
                await _cmdChar.WriteValueAsync(writer.DetachBuffer());
                if (command.StartsWith("LED_")) ShowStatus(led: command == "LED_ON" ? "WHITE" : "OFF");
            }
            catch (Exception ex) { Error("Loi gui BLE: " + ex.Message); }
        }

        private async void btnOpenDoor_Click(object s, EventArgs e) => await SendCommandAsync("OPEN_DOOR");
        private async void btnCloseDoor_Click(object s, EventArgs e) => await SendCommandAsync("CLOSE_DOOR");
        private async void btnOpenRoof_Click(object s, EventArgs e) => await SendCommandAsync("OPEN_ROOF");
        private async void btnCloseRoof_Click(object s, EventArgs e) => await SendCommandAsync("CLOSE_ROOF");
        private async void btnLedOn_Click(object s, EventArgs e) => await SendCommandAsync("LED_ON");
        private async void btnLedOff_Click(object s, EventArgs e) => await SendCommandAsync("LED_OFF");

        // Sự kiện Reset toàn bộ hệ thống về mặc định ban đầu
        private async void btnResetSystem_Click(object sender, EventArgs e)
        {
            var confirm = MessageBox.Show(
                "Xác nhận đưa toàn bộ hệ thống về trạng thái ban đầu?\n- Cửa: ĐÓNG\n- Mái che: MỞ\n- Đèn LED: BẬT TRẮNG",
                "Xác nhận Reset Hệ Thống",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirm == DialogResult.Yes)
            {
                await SendCommandAsync("RESET_SYSTEM");
            }
        }

        private async Task<bool> CardActionAsync(HttpMethod method, string path, object body, string okMsg)
        {
            try
            {
                await ApiAsync(method, path, body);
                Info(okMsg);
                await RefreshCardsAsync(); await RefreshEventsAsync();
                return true;
            }
            catch (Exception ex) { Error(ex.Message); return false; }
        }

        private string SelectedCell(string column, string emptyMsg)
        {
            if (dgvCards.SelectedRows.Count == 0) { Warn(emptyMsg); return null; }
            return dgvCards.SelectedRows[0].Cells[column].Value?.ToString();
        }

        private async void btnAddCard_Click(object sender, EventArgs e)
        {
            string uid = txtNewUid.Text.Trim().ToUpper(), holder = txtNewHolder.Text.Trim();
            if (uid.Length == 0 || holder.Length == 0) { Warn("Vui long nhap du Ma UID va Ten chu the!"); return; }
            if (await CardActionAsync(HttpMethod.Post, "/api/cards", new { uid, holder }, "Them the moi thanh cong!"))
            { txtNewUid.Clear(); txtNewHolder.Clear(); }
        }

        private async void btnToggleCard_Click(object sender, EventArgs e)
        {
            string uid = SelectedCell("uid", "Vui long chon the can Khoa / Mo!");
            if (uid == null) return;
            bool active = SelectedCell("active", "") != "Dang hoat dong";
            await CardActionAsync(HttpMethod.Put, "/api/cards", new { uid, active }, active ? "Da kich hoat lai the!" : "Da vo hieu hoa the!");
        }

        private async void btnDeleteCard_Click(object sender, EventArgs e)
        {
            string uid = SelectedCell("uid", "Vui long chon the can xoa tren bang!");
            if (uid == null || MessageBox.Show($"Xac nhan xoa hoan toan the UID: {uid}?", "Xac nhan",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            await CardActionAsync(HttpMethod.Delete, $"/api/cards?uid={Uri.EscapeDataString(uid)}", null, "Da xoa the khoi he thong!");
        }

        private async void btnRefreshDeviceLogs_Click(object sender, EventArgs e) => await RefreshDeviceLogsAsync();
        private async void btnRefreshEvents_Click(object sender, EventArgs e) => await RefreshEventsAsync();
        private async void btnRefreshLogs_Click(object sender, EventArgs e) => await RefreshLogsAsync();
        private async void txtFilterUid_TextChanged(object sender, EventArgs e) => await RefreshLogsAsync();
        private async void cboFilterStatus_SelectedIndexChanged(object sender, EventArgs e) => await RefreshLogsAsync();

        private void txtIpAddress_TextChanged(object sender, EventArgs e)
        {

        }
    }
}