import os, time, hashlib, sqlite3, logging, threading, unicodedata, json
from datetime import datetime
from dotenv import load_dotenv
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS

def _imp(s):
    try: exec(s, globals()); return True
    except Exception: return False

pyodbc = pigpio = GPIO = PixelStrip = Color = board = busio = adafruit_ssd1306 = None
Image = ImageDraw = ImageFont = SimpleMFRC522 = dbus = GLib = mqtt = None

ODBC_OK = _imp("import pyodbc")
_imp("import pigpio, board, busio, adafruit_ssd1306, RPi.GPIO as GPIO")
_imp("from rpi_ws281x import PixelStrip, Color")
_imp("from PIL import Image, ImageDraw, ImageFont\nfrom mfrc522 import SimpleMFRC522")
BLE_OK = _imp("import dbus, dbus.service, dbus.mainloop.glib\nfrom gi.repository import GLib")
MQTT_OK = _imp("import paho.mqtt.client as mqtt")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("Hotel_IoT")

CACHE_DB, STATE_FILE = os.path.join(BASE_DIR, "offline_cache.db"), os.path.join(BASE_DIR, "system_state.json")
TEMPLATE_DIR, STATIC_DIR = os.path.abspath(os.path.join(BASE_DIR, "../website/templates")), os.path.abspath(os.path.join(BASE_DIR, "../website/static"))

PIN_SERVO_DOOR, PIN_SERVO_ROOF, PIN_RAIN_DO = 22, 23, 27
PIN_WS2812, PIN_RFID_RST, NUM_LEDS = 18, 25, 8
RAIN_ACTIVE_LOW = True
DOOR_CLOSE, DOOR_OPEN = 650, 1700
ROOF_CLOSE, ROOF_OPEN = 650, 2100
DOOR_HOLD_RFID, RAIN_SAMPLES, RAIN_PERIOD, RFID_COOLDOWN, CACHE_KEEP = 5.0, 3, 0.4, 2.0, 500

DEVICE_ID = "RPI_ROOM_101"
API_TOKEN = "Bearer " + os.getenv("API_TOKEN", "HotelIoTToken2026")
ADMIN_HASH = os.getenv("ADMIN_HASH", "240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9")
SQL_CONN_STR = (f"DRIVER={{FreeTDS}};SERVER={os.getenv('SQL_HOST', '192.168.127.239')};PORT={os.getenv('SQL_PORT', '14333')};"
                f"DATABASE={os.getenv('SQL_DATABASE', 'HotelIoT')};UID={os.getenv('SQL_USER', 'sa')};"
                f"PWD={os.getenv('SQL_PASSWORD', '123')};TDS_Version=7.4;Connection Timeout=3;")

MQTT_HOST, MQTT_PORT = "localhost", 10364
TOPIC_SUB_COMMAND, TOPIC_PUB_STATUS = "hotel/room101/command", "hotel/room101/status"
BLE_NAME, SERVICE_UUID = "Khachsan_TuanHuy", "0000ffe0-0000-1000-8000-00805f9b34fb"
CHAR_STATUS_UUID, CHAR_CMD_UUID = "0000ffe1-0000-1000-8000-00805f9b34fb", "0000ffe2-0000-1000-8000-00805f9b34fb"

LOG_TABLES = {
    "RFIDLogs": ("LogId", ["UID", "AccessTime", "AccessStatus", "DeviceId", "Notes", "Source"]),
    "DeviceLogs": ("LogId", ["DeviceName", "Action", "TriggerSource", "Details", "LogTime"]),
    "SystemEvents": ("EventId", ["EventTime", "EventType", "Description", "Severity"]),
}
UID_EXPR = "REPLACE(UPPER(UID), ' ', '')"
DEFAULT_CARDS = [("1B EA D8 99 B", "Phong 101 - The Khach VIP"), ("E1 02 A0 7B 38", "Ban Quan Ly - The Master"), ("DF BF B7 C4 13", "Nhan Vien - Don Phong 101")]

def now(): return time.strftime("%Y-%m-%d %H:%M:%S")
def compact_uid(uid): return uid.replace(" ", "").strip().upper()

def get_state():
    try:
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE, "r", encoding="utf-8") as f: return json.load(f)
    except Exception: pass
    return {"door": "OPEN", "clean_reset": False}

def set_state(door, reset):
    try:
        with open(STATE_FILE, "w", encoding="utf-8") as f: json.dump({"door": door, "clean_reset": reset}, f)
    except Exception: pass

class Store:
    def __init__(self):
        self.lock, self.sql, self.online = threading.RLock(), None, False
        with self._lite() as c:
            for t, (pk, cols) in LOG_TABLES.items():
                c.execute(f"CREATE TABLE IF NOT EXISTS {t} ({pk} INTEGER PRIMARY KEY AUTOINCREMENT, {', '.join(cols)}, Synced INTEGER DEFAULT 0)")
            c.execute("CREATE TABLE IF NOT EXISTS RFIDCards (CardId INTEGER PRIMARY KEY AUTOINCREMENT, UID TEXT UNIQUE, CardHolder TEXT, IsActive INTEGER DEFAULT 1, ValidTo TEXT)")
            c.executemany("INSERT OR IGNORE INTO RFIDCards (UID, CardHolder) VALUES (?, ?)", DEFAULT_CARDS)
        self.check_connection()

    @staticmethod
    def _lite(): return sqlite3.connect(CACHE_DB)

    def check_connection(self):
        with self.lock:
            if self.online:
                try: self.sql.cursor().execute("SELECT 1").fetchone(); return True
                except Exception: self.online = False
            if not ODBC_OK: return False
            try:
                self.sql = pyodbc.connect(SQL_CONN_STR); self.online = True
                log.info("Da ket noi SQL Server -> dong bo du lieu")
                self._push_offline(); self._pull_cards()
            except Exception as e: log.warning(f"Chua ket noi SQL Server: {e}")
            return self.online

    def _sql_exec(self, query, params=()):
        if not self.online: return None
        try: cur = self.sql.cursor(); cur.execute(query, params); return cur
        except Exception: self.online = False; return None

    def _commit(self):
        try: self.sql.commit(); return True
        except Exception: self.online = False; return False

    def write(self, table, **row):
        cols = LOG_TABLES[table][1]; vals = [row.get(c) for c in cols]; marks = ", ".join("?" * len(cols))
        with self.lock:
            synced = int(self._sql_exec(f"INSERT INTO {table} ({', '.join(cols)}) VALUES ({marks})", vals) is not None and self._commit())
            with self._lite() as c: c.execute(f"INSERT INTO {table} ({', '.join(cols)}, Synced) VALUES ({marks}, ?)", vals + [synced])

    def log_access(self, uid, st, notes): self.write("RFIDLogs", UID=uid, AccessTime=now(), AccessStatus=st, DeviceId=DEVICE_ID, Notes=notes, Source="RFID_RC522")
    def log_device(self, dev, act, src, det=""): self.write("DeviceLogs", DeviceName=dev, Action=act, TriggerSource=src, Details=det, LogTime=now())
    def log_event(self, etype, desc, sev="INFO"): self.write("SystemEvents", EventTime=now(), EventType=etype, Description=desc, Severity=sev)

    def select(self, table, cols, where="", params=(), n=50, pk="LogId"):
        w = f" WHERE {where}" if where else ""
        with self.lock:
            cur = self._sql_exec(f"SELECT TOP {n} {pk}, {cols} FROM {table}{w} ORDER BY {pk} DESC", params)
            if cur: return [list(r) for r in cur.fetchall()]
            with self._lite() as c: return c.execute(f"SELECT {pk}, {cols} FROM {table}{w} ORDER BY {pk} DESC LIMIT {n}", params).fetchall()

    def verify_card(self, uid):
        q = f"SELECT 1 FROM RFIDCards WHERE {UID_EXPR} = ? AND IsActive = 1 AND (ValidTo IS NULL OR ValidTo >= ?)"
        with self.lock:
            cur = self._sql_exec(q, (compact_uid(uid), datetime.now()))
            if cur: return cur.fetchone() is not None
            with self._lite() as c: return c.execute(q, (compact_uid(uid), now())).fetchone() is not None

    def card_exec(self, query, params):
        with self.lock:
            if self._sql_exec(query, params): self._commit()
            with self._lite() as c: c.execute(query, params)

    def upsert_card(self, uid, holder):
        with self.lock:
            cur = self._sql_exec(f"UPDATE RFIDCards SET CardHolder = ?, IsActive = 1 WHERE {UID_EXPR} = ?", (holder, compact_uid(uid)))
            if cur and cur.rowcount == 0: cur = self._sql_exec("INSERT INTO RFIDCards (UID, CardHolder, IsActive) VALUES (?, ?, 1)", (uid, holder))
            if cur: self._commit()
            with self._lite() as c:
                if c.execute(f"UPDATE RFIDCards SET CardHolder = ?, IsActive = 1 WHERE {UID_EXPR} = ?", (holder, compact_uid(uid))).rowcount == 0:
                    c.execute("INSERT INTO RFIDCards (UID, CardHolder, IsActive) VALUES (?, ?, 1)", (uid, holder))

    def update_status(self, door, roof, rain, led):
        with self.lock:
            p = (door, roof, "RAINING" if rain else "NO_RAIN", led, now(), DEVICE_ID)
            cur = self._sql_exec("UPDATE DeviceStatus SET DoorStatus=?, RoofStatus=?, RainStatus=?, LedStatus=?, LastUpdated=? WHERE DeviceId=?", p)
            if cur and cur.rowcount == 0: cur = self._sql_exec("INSERT INTO DeviceStatus (DoorStatus, RoofStatus, RainStatus, LedStatus, LastUpdated, DeviceId) VALUES (?, ?, ?, ?, ?, ?)", p)
            if cur: self._commit()

    def _push_offline(self):
        tot = 0
        with self._lite() as c:
            for t, (pk, cols) in LOG_TABLES.items():
                rows = c.execute(f"SELECT {pk}, {', '.join(cols)} FROM {t} WHERE Synced = 0").fetchall()
                if rows:
                    cur = self.sql.cursor()
                    cur.executemany(f"INSERT INTO {t} ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})", [r[1:] for r in rows])
                    self.sql.commit()
                    c.executemany(f"UPDATE {t} SET Synced = 1 WHERE {pk} = ?", [(r[0],) for r in rows])
                    tot += len(rows)
                c.execute(f"DELETE FROM {t} WHERE Synced = 1 AND {pk} NOT IN (SELECT {pk} FROM {t} ORDER BY {pk} DESC LIMIT {CACHE_KEEP})")
        if tot: log.info(f"Da day {tot} ban ghi offline len SQL")

    def _pull_cards(self):
        rows = self.sql.cursor().execute("SELECT UID, CardHolder, IsActive, ValidTo FROM RFIDCards").fetchall()
        with self._lite() as c:
            c.execute("DELETE FROM RFIDCards")
            c.executemany("INSERT OR REPLACE INTO RFIDCards (UID, CardHolder, IsActive, ValidTo) VALUES (?, ?, ?, ?)",
                          [(r[0], r[1], int(r[2]), r[3].strftime("%Y-%m-%d %H:%M:%S") if r[3] else None) for r in rows])

    def verify_user(self, user, pwd):
        h = hashlib.sha256(pwd.encode()).hexdigest()
        with self.lock:
            cur = self._sql_exec("SELECT Role, PasswordHash FROM Users WHERE Username = ? AND IsActive = 1", (user,))
            if cur:
                r = cur.fetchone()
                return r[0] if r and r[1] == h else None
        return "Admin" if user == "admin" and h == ADMIN_HASH else None

class Servo:
    def __init__(self, pi, pin, name, p_close, p_open, start_open=False, move_on_init=True):
        self.pi, self.pin, self.name, self.p_close, self.p_open = pi, pin, name, p_close, p_open
        self.lock, self.is_open = threading.Lock(), None
        if move_on_init: 
            self.set(start_open)
        else: 
            self.is_open = start_open

    def set(self, open_):
        with self.lock:
            if self.is_open == open_: 
                return
            self.is_open = open_
            if self.pi and self.pi.connected:
                self.pi.set_servo_pulsewidth(self.pin, self.p_open if open_ else self.p_close)
                time.sleep(0.55)
                self.pi.set_servo_pulsewidth(self.pin, 0)

    @property
    def state(self): return "OPEN" if self.is_open else "CLOSED"

class Led:
    RGB = {"OFF": (0, 0, 0), "WHITE": (120, 120, 120), "GREEN": (0, 180, 0), "RED": (180, 0, 0), "YELLOW": (180, 140, 0)}
    def __init__(self):
        self.color, self.strip = "OFF", None
        try:
            if os.geteuid() == 0:
                self.strip = PixelStrip(NUM_LEDS, PIN_WS2812, 800000, 10, False, 150, 0)
                self.strip.begin()
        except Exception as e: log.warning(f"Bo qua LED: {e}")

    def set(self, color):
        self.color = color
        if self.strip:
            c = Color(*self.RGB.get(color, (0, 0, 0)))
            for i in range(NUM_LEDS): self.strip.setPixelColor(i, c)
            self.strip.show()

class Oled:
    def __init__(self):
        self.lines, self.dev = ("", ""), None
        try:
            self.dev = adafruit_ssd1306.SSD1306_I2C(128, 32, busio.I2C(board.SCL, board.SDA), addr=0x3C)
            self.img = Image.new("1", (128, 32))
            self.draw, self.font = ImageDraw.Draw(self.img), ImageFont.load_default()
        except Exception as e: log.warning(f"Bo qua OLED: {e}")

    @staticmethod
    def ascii(text):
        t = str(text).replace("\u0111", "d").replace("\u0110", "D")
        return unicodedata.normalize("NFD", t).encode("ascii", "ignore").decode().upper()[:18]

    def show(self, line1, line2=""):
        self.lines = (self.ascii(line1), self.ascii(line2))
        if self.dev:
            try:
                self.draw.rectangle((0, 0, 128, 32), fill=0)
                self.draw.text((2, 2), self.lines[0], font=self.font, fill=255)
                self.draw.line([(0, 15), (127, 15)], fill=255)
                self.draw.text((2, 18), self.lines[1], font=self.font, fill=255)
                self.dev.image(self.img); self.dev.show()
            except Exception: pass

class Rfid:
    def __init__(self): self.reader, self.last_uid, self.last_seen = None, None, 0.0
    def _init(self):
        try:
            GPIO.setmode(GPIO.BCM); GPIO.setup(PIN_RFID_RST, GPIO.OUT)
            for lv in (GPIO.LOW, GPIO.HIGH): GPIO.output(PIN_RFID_RST, lv); time.sleep(0.05)
            self.reader = SimpleMFRC522()
        except Exception: pass

    def read(self):
        if not self.reader: self._init(); return None
        try: num = self.reader.read_id_no_block()
        except Exception: self.reader = None; return None
        if num is None: return None
        h = hex(num)[2:].upper(); uid = " ".join(h[i:i+2] for i in range(0, len(h), 2)).strip()
        t = time.time(); repeat = uid == self.last_uid and t - self.last_seen < RFID_COOLDOWN
        self.last_uid, self.last_seen = uid, t
        return None if repeat else uid

class MqttHandler:
    def __init__(self, hotel): self.hotel, self.client, self.connected = hotel, None, False
    def start(self):
        if MQTT_OK: threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        try:
            self.client = mqtt.Client()
            self.client.on_connect = lambda c, u, f, rc: (setattr(self, "connected", rc == 0), c.subscribe(TOPIC_SUB_COMMAND), self.publish_status()) if rc == 0 else None
            self.client.on_message = lambda c, u, m: threading.Thread(target=self.hotel.command, args=(json.loads(m.payload.decode()).get("command", "") if m.payload.decode().strip().startswith("{") else m.payload.decode().strip(), "MQTT"), daemon=True).start()
            self.client.connect(MQTT_HOST, MQTT_PORT, 60); self.client.loop_forever()
        except Exception: pass

    def publish_status(self):
        if self.connected and self.client:
            try: self.client.publish(TOPIC_PUB_STATUS, json.dumps(self.hotel.status()), qos=0)
            except Exception: pass

class Ble:
    def __init__(self, hotel): self.hotel, self.status_chrc = hotel, None
    def start(self):
        if BLE_OK: threading.Thread(target=self._run, daemon=True).start()
    def notify(self):
        if self.status_chrc: GLib.idle_add(self.status_chrc.notify)
    def _run(self):
        try: build_gatt(self)
        except Exception: pass

if BLE_OK:
    BLUEZ, PROPS, OM = "org.bluez", "org.freedesktop.DBus.Properties", "org.freedesktop.DBus.ObjectManager"
    CHRC_IF, SVC_IF, ADV_IF = "org.bluez.GattCharacteristic1", "org.bluez.GattService1", "org.bluez.LEAdvertisement1"

    class DObj(dbus.service.Object):
        def __init__(self, bus, path): self.path = path; super().__init__(bus, path)
        def get_path(self): return dbus.ObjectPath(self.path)
        def props(self): return {}
        @dbus.service.method(PROPS, in_signature="s", out_signature="a{sv}")
        def GetAll(self, iface): return self.props()

    class Advert(DObj):
        def props(self): return {"Type": "peripheral", "LocalName": dbus.String(BLE_NAME), "ServiceUUIDs": dbus.Array([SERVICE_UUID], signature="s"), "Discoverable": dbus.Boolean(True)}
        @dbus.service.method(ADV_IF)
        def Release(self): pass

    class Service(DObj):
        def __init__(self, bus): super().__init__(bus, "/org/bluez/hotel/service0"); self.chrcs = []
        def props(self): return {"UUID": SERVICE_UUID, "Primary": True, "Characteristics": dbus.Array([c.get_path() for c in self.chrcs], signature="o")}

    class Chrc(DObj):
        def __init__(self, bus, svc, idx, uuid, flags, hotel):
            super().__init__(bus, f"{svc.path}/char{idx}")
            self.svc, self.uuid, self.flags, self.hotel, self.notifying = svc, uuid, flags, hotel, False
            svc.chrcs.append(self)
        def props(self): return {"Service": self.svc.get_path(), "UUID": self.uuid, "Flags": self.flags}
        def _value(self): return [dbus.Byte(b) for b in self.hotel.short_status().encode()]
        @dbus.service.method(CHRC_IF, in_signature="a{sv}", out_signature="ay")
        def ReadValue(self, opt): return self._value()
        @dbus.service.method(CHRC_IF, in_signature="aya{sv}")
        def WriteValue(self, val, opt): threading.Thread(target=self.hotel.command, args=(bytes(val).decode(errors="ignore").strip(), "BLE"), daemon=True).start()
        @dbus.service.method(CHRC_IF)
        def StartNotify(self): self.notifying = True
        @dbus.service.method(CHRC_IF)
        def StopNotify(self): self.notifying = False
        def notify(self):
            if self.notifying: self.PropertiesChanged(CHRC_IF, {"Value": self._value()}, [])
            return False
        @dbus.service.signal(PROPS, signature="sa{sv}as")
        def PropertiesChanged(self, iface, changed, inv): pass

    class App(DObj):
        def __init__(self, bus, svc): super().__init__(bus, "/"); self.svc = svc
        @dbus.service.method(OM, out_signature="a{oa{sa{sv}}}")
        def GetManagedObjects(self):
            o = {self.svc.get_path(): {SVC_IF: self.svc.props()}}
            o.update({c.get_path(): {CHRC_IF: c.props()} for c in self.svc.chrcs})
            return o

    def build_gatt(ble):
        dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
        bus = dbus.SystemBus()
        objs = dbus.Interface(bus.get_object(BLUEZ, "/"), OM).GetManagedObjects()
        adapter = next((p for p, i in objs.items() if "org.bluez.GattManager1" in i), "/org/bluez/hci0")
        obj = bus.get_object(BLUEZ, adapter); props = dbus.Interface(obj, PROPS)
        for k, v in (("Powered", dbus.Boolean(1)), ("Alias", dbus.String(BLE_NAME)), ("Discoverable", dbus.Boolean(1))): props.Set("org.bluez.Adapter1", k, v)
        svc = Service(bus)
        ble.status_chrc = Chrc(bus, svc, 0, CHAR_STATUS_UUID, ["read", "notify"], ble.hotel)
        Chrc(bus, svc, 1, CHAR_CMD_UUID, ["write", "write-without-response"], ble.hotel)
        app, adv = App(bus, svc), Advert(bus, "/org/bluez/hotel/advertisement0")
        dbus.Interface(obj, "org.bluez.GattManager1").RegisterApplication(app.get_path(), {}, reply_handler=lambda: log.info("[BLE] GATT OK"), error_handler=lambda e: None)
        dbus.Interface(obj, "org.bluez.LEAdvertisingManager1").RegisterAdvertisement(adv.get_path(), {}, reply_handler=lambda: log.info(f"[BLE] Adv {BLE_NAME}"), error_handler=lambda e: None)
        GLib.MainLoop().run()

class Hotel:
    def __init__(self):
        log.info("Khoi dong Hotel IoT...")
        self.pi = pigpio.pi() if pigpio else None
        if self.pi and self.pi.connected:
            self.pi.set_mode(PIN_RAIN_DO, pigpio.INPUT); self.pi.set_pull_up_down(PIN_RAIN_DO, pigpio.PUD_UP)
        else:
            try: GPIO.setwarnings(False); GPIO.setmode(GPIO.BCM); GPIO.setup(PIN_RAIN_DO, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            except Exception: pass

        self.db = Store()
        is_reset = get_state().get("clean_reset", False)
        self.door = Servo(self.pi, PIN_SERVO_DOOR, "DOOR_SERVO", DOOR_CLOSE, DOOR_OPEN, start_open=False, move_on_init=not is_reset)
        if not is_reset: set_state("CLOSED", True)
        self.roof = Servo(self.pi, PIN_SERVO_ROOF, "ROOF_SERVO", ROOF_CLOSE, ROOF_OPEN, start_open=True, move_on_init=True)

        self.led, self.oled, self.rfid = Led(), Oled(), Rfid()
        self.raining, self.light_on, self.flash_until, self.door_timer = False, True, 0.0, None
        self.last_cmd_id, self.cmd_lock = None, threading.Lock()
        self.ble, self.mqtt = Ble(self), MqttHandler(self)
        self.refresh(); self.db.log_event("SYSTEM_START", "Pi 3B+ san sang hoat dong")

    def read_rain(self):
        try:
            raw = self.pi.read(PIN_RAIN_DO) if (self.pi and self.pi.connected) else (GPIO.setmode(GPIO.BCM) or GPIO.input(PIN_RAIN_DO))
            return raw == (0 if RAIN_ACTIVE_LOW else 1)
        except Exception: return False

    def refresh(self):
        if time.time() < self.flash_until: return
        if self.raining: self.led.set("YELLOW"); self.oled.show("WEATHER ALERT", "ROOF: " + self.roof.state)
        else: self.led.set("WHITE" if self.light_on else "OFF"); self.oled.show("HOTEL ROOM 101", "DOOR: " + ("OPEN" if self.door.is_open else "LOCKED"))
        self.sync()

    def flash(self, color, l1, l2, s):
        self.flash_until = time.time() + s; self.led.set(color); self.oled.show(l1, l2); self.sync()
        t = threading.Timer(s + 0.05, self.refresh); t.daemon = True; t.start()

    def sync(self):
        self.ble.notify(); self.mqtt.publish_status()
        self.db.update_status(self.door.state, self.roof.state, self.raining, self.led.color)

    def open_door(self, src, hold=None):
        if self.door_timer: self.door_timer.cancel(); self.door_timer = None
        self.door.set(True); set_state("OPEN", False); self.db.log_device("DOOR_SERVO", "OPEN", src, f"Mo cua ({src})")
        if hold and hold > 0:
            self.door_timer = threading.Timer(hold, self.close_door, args=("AUTO_TIMEOUT",)); self.door_timer.daemon = True; self.door_timer.start()
        if src != "RFID_CARD": self.flash("GREEN", "REMOTE COMMAND", "DOOR: OPENED", 2.0)
        else: self.refresh()
        return True

    def close_door(self, src):
        if self.door_timer: self.door_timer.cancel(); self.door_timer = None
        self.door.set(False); set_state("CLOSED", False); self.db.log_device("DOOR_SERVO", "CLOSED", src, f"Dong cua ({src})")
        self.refresh(); return True

    def set_roof(self, op, src):
        if op and self.raining and src != "RAIN_SENSOR": self.db.log_event("ROOF_BLOCKED", f"Tu choi mo mai qua {src} vi mua", "WARNING"); return False
        self.roof.set(op); self.db.log_device("ROOF_SERVO", self.roof.state, src, f"{'Mo' if op else 'Dong'} mai ({src})"); self.refresh(); return True

    def set_light(self, on, src):
        self.light_on = on; self.db.log_device("LED_WS2812", "ON" if on else "OFF", src, f"{'Bat' if on else 'Tat'} den ({src})"); self.refresh(); return True

    def reset_system(self, src="MANUAL"):
        log.info(f"RESET he thong tu: {src}")
        if self.door_timer: self.door_timer.cancel(); self.door_timer = None
        self.door.set(False); self.roof.set(True); self.light_on = True; self.raining = False; self.flash_until = 0.0
        set_state("CLOSED", True); self.refresh()
        self.db.log_event("SYSTEM_RESET", f"Reset ve mac dinh ({src})", "WARNING")
        self.db.log_device("SYSTEM", "RESET", src, "Reset toan bo ve mac dinh")
        return True

    def command(self, cmd, src="REMOTE", cmd_id=""):
        with self.cmd_lock:
            if cmd_id and cmd_id == self.last_cmd_id: return True
            self.last_cmd_id = cmd_id or self.last_cmd_id
        actions = {
            "OPEN_DOOR": lambda: self.open_door(src, hold=None), "CLOSE_DOOR": lambda: self.close_door(src),
            "OPEN_ROOF": lambda: self.set_roof(True, src), "CLOSE_ROOF": lambda: self.set_roof(False, src),
            "LED_ON": lambda: self.set_light(True, src), "LED_OFF": lambda: self.set_light(False, src),
            "RESET_SYSTEM": lambda: self.reset_system(src)
        }
        if cmd not in actions: return False
        log.info(f"Lenh [{src}]: {cmd}"); return actions[cmd]()

    def loop_rfid(self):
        while True:
            uid = self.rfid.read()
            if uid:
                if self.db.verify_card(uid):
                    self.db.log_access(uid, "ACCESS", "Mo cua bang the hop le")
                    self.flash("GREEN", "ACCESS GRANTED", "UID:" + uid[:12], 2.5)
                    self.open_door("RFID_CARD", hold=DOOR_HOLD_RFID)
                else:
                    self.db.log_access(uid, "DENIED", "The khong hop le / het han")
                    self.flash("RED", "ACCESS DENIED", "INVALID CARD", 2.5)
            time.sleep(0.05)

    def loop_rain(self):
        c = 0
        while True:
            is_r = self.read_rain(); c = c + 1 if is_r != self.raining else 0
            if c >= RAIN_SAMPLES:
                c, self.raining = 0, not self.raining
                self.db.log_event("RAIN_DETECTED" if self.raining else "RAIN_CLEARED", "Phat hien mua" if self.raining else "Tanh mua", "WARNING" if self.raining else "INFO")
                self.set_roof(not self.raining, "RAIN_SENSOR")
            time.sleep(RAIN_PERIOD)

    def loop_heartbeat(self):
        while True: time.sleep(4.0); self.db.check_connection(); self.sync()

    def status(self):
        return {"device_id": DEVICE_ID, "door": self.door.state, "roof": self.roof.state, "rain": self.raining,
                "led": self.led.color, "oled": " | ".join(self.oled.lines), "sql_connected": self.db.online,
                "wifi_connected": True, "ble_active": BLE_OK, "mqtt_port": MQTT_PORT}

    def short_status(self): return f"D:{int(bool(self.door.is_open))},R:{int(bool(self.roof.is_open))},W:{int(self.raining)}"

    def run(self):
        self.ble.start(); self.mqtt.start()
        app = create_web(self)
        threading.Thread(target=lambda: app.run(host="0.0.0.0", port=5000, threaded=True), daemon=True).start()
        threading.Thread(target=self.loop_rain, daemon=True).start()
        threading.Thread(target=self.loop_heartbeat, daemon=True).start()
        self.loop_rfid()

    def cleanup(self):
        log.info("Dung he thong, giai phong GPIO...")
        if self.door and self.door.is_open:
            self.door.set(False)
        self.led.set("OFF"); self.oled.show("", "")
        if self.pi and self.pi.connected:
            self.pi.set_servo_pulsewidth(PIN_SERVO_DOOR, 0)
            self.pi.set_servo_pulsewidth(PIN_SERVO_ROOF, 0)
            self.pi.stop()

def rows(data, keys):
    return [dict(zip(keys, (str(v) if v is not None and k == "time" else v for k, v in zip(keys, r)))) for r in data]

def create_web(hotel):
    app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=STATIC_DIR)
    CORS(app); db = hotel.db

    @app.before_request
    def auth():
        if request.method == "OPTIONS": return None
        public = request.path in ("/", "/api/login", "/api/status") or request.path.startswith("/static")
        if not public and request.headers.get("Authorization") != API_TOKEN:
            return jsonify(status="error", message="Unauthorized"), 401

    @app.get("/")
    def index(): return render_template("index.html")

    @app.post("/api/login")
    def login():
        d = request.get_json(silent=True) or {}
        user, pwd = d.get("username", "").strip(), d.get("password", "").strip()
        role = db.verify_user(user, pwd)
        db.log_event("AUTH_LOGIN" if role else "AUTH_FAILED", f"Dang nhap {'thanh cong' if role else 'that bai'}: '{user}'", "INFO" if role else "WARNING")
        return jsonify(status="success", token=API_TOKEN, role=role) if role else (jsonify(status="error", message="Sai thong tin"), 401)

    @app.get("/api/status")
    def status(): return jsonify(hotel.status())

    @app.post("/api/control")
    def control():
        d = request.get_json(silent=True) or {}
        ok = hotel.command(d.get("command", ""), "WIFI_API", d.get("cmd_id", ""))
        return jsonify(status="success" if ok else "failed", command=d.get("command"))

    @app.route("/api/cards", methods=["GET", "POST", "PUT", "DELETE"])
    def cards():
        if request.method == "GET":
            return jsonify([{"id": r[0], "uid": r[1], "holder": r[2], "active": bool(r[3])} for r in db.select("RFIDCards", "UID, CardHolder, IsActive", n=200, pk="CardId")])
        d = request.get_json(silent=True) or {}
        uid = (d.get("uid") or request.args.get("uid", "")).strip().upper()
        if not uid: return jsonify(status="error", message="Thieu UID"), 400
        if request.method == "POST":
            db.upsert_card(uid, d.get("holder", "Khach").strip()); db.log_event("CARD_ADDED", f"Them the UID: {uid}")
        elif request.method == "PUT":
            db.card_exec(f"UPDATE RFIDCards SET IsActive = ? WHERE {UID_EXPR} = ?", (int(bool(d.get("active", True))), compact_uid(uid)))
            db.log_event("CARD_UPDATED", f"Cap nhat the UID: {uid}")
        else:
            db.card_exec(f"DELETE FROM RFIDCards WHERE {UID_EXPR} = ?", (compact_uid(uid),)); db.log_event("CARD_DELETED", f"Xoa the: {uid}", "WARNING")
        return jsonify(status="success")

    @app.get("/api/logs")
    def logs():
        uid, st = request.args.get("uid", "").strip(), request.args.get("status", "").strip()
        w, p = ["1=1"], []
        if uid: w.append("UID LIKE ?"); p.append(f"%{uid}%")
        if st: w.append("AccessStatus = ?"); p.append(st)
        return jsonify(rows(db.select("RFIDLogs", "UID, AccessTime, AccessStatus, Notes", " AND ".join(w), tuple(p)), ["id", "uid", "time", "status", "notes"]))

    @app.get("/api/device-logs")
    def device_logs():
        return jsonify(rows(db.select("DeviceLogs", "DeviceName, Action, TriggerSource, Details, LogTime"), ["id", "device", "action", "source", "details", "time"]))

    @app.get("/api/events")
    def events():
        return jsonify(rows(db.select("SystemEvents", "EventTime, EventType, Description, Severity", n=30, pk="EventId"), ["id", "time", "type", "desc", "severity"]))

    return app

if __name__ == "__main__":
    hotel = Hotel()
    try: hotel.run()
    except KeyboardInterrupt: hotel.cleanup()