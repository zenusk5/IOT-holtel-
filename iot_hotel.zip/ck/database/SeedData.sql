USE HotelIoT;
GO

DELETE FROM dbo.Users;
INSERT INTO dbo.Users (Username, PasswordHash, Role, IsActive)
VALUES ('admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'Admin', 1);

DELETE FROM dbo.RFIDCards;
INSERT INTO dbo.RFIDCards (UID, CardHolder, IsActive, ValidFrom, ValidTo, CardType, Description)
VALUES
    ('01 BE AD 89', N'Phong 101 - The Khach VIP', 1, GETDATE(), DATEADD(year, 2, GETDATE()), 'GUEST', N'The khach luu tru VIP'),
    ('E1 02 A0 7B', N'Ban Quan Ly - The Master', 1, GETDATE(), DATEADD(year, 2, GETDATE()), 'MASTER', N'The tong mo tat ca cac phong'),
    ('DF BF B7 C4', N'Nhan Vien - Don Phong 101', 1, GETDATE(), DATEADD(year, 2, GETDATE()), 'CLEANING', N'The buong phong don dep');

DELETE FROM dbo.DeviceStatus;
INSERT INTO dbo.DeviceStatus (DeviceId, DoorStatus, RoofStatus, RainStatus, LedStatus, WifiStatus, BleStatus)
VALUES ('RPI_ROOM_101', 'CLOSED', 'OPEN', 'NO_RAIN', 'WHITE', 'CONNECTED', 'ACTIVE');

INSERT INTO dbo.SystemEvents (EventType, Description, Severity)
VALUES ('SYSTEM_INIT', N'Co so du lieu HotelIoT da khoi tao day du 6 bang dong bo', 'INFO');

INSERT INTO dbo.DeviceLogs (DeviceName, Action, TriggerSource, Details)
VALUES
    ('DOOR_SERVO', 'CLOSED', 'SYSTEM_INIT', N'Cua phong khoi tao trang thai dong an toan'),
    ('ROOF_SERVO', 'OPEN', 'SYSTEM_INIT', N'Mai che khoi tao trang thai mo thoang'),
    ('LED_WS2812', 'ON', 'SYSTEM_INIT', N'Den LED khoi tao mau trang cho');
GO

PRINT N'Da nap toan bo du lieu khoi tao thanh cong!';
GO
