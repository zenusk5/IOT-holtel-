USE HotelIoT;
GO
;WITH c AS (
    SELECT CardId, RIGHT('0000000000' + REPLACE(UID, ' ', ''), 10) AS h
    FROM dbo.RFIDCards WHERE LEN(REPLACE(UID, ' ', '')) IN (9, 10)
)
UPDATE r SET UID = SUBSTRING(h,1,2) + ' ' + SUBSTRING(h,3,2) + ' ' + SUBSTRING(h,5,2) + ' ' + SUBSTRING(h,7,2),
             UpdatedAt = GETDATE()
FROM dbo.RFIDCards r JOIN c ON r.CardId = c.CardId;
GO
SELECT CardId, UID, CardHolder FROM dbo.RFIDCards;
GO
