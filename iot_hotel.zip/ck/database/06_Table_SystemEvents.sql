USE HotelIoT;
GO

IF OBJECT_ID('dbo.SystemEvents', 'U') IS NOT NULL DROP TABLE dbo.SystemEvents;
GO

CREATE TABLE dbo.SystemEvents (
    EventId BIGINT IDENTITY(1,1) PRIMARY KEY,
    EventTime DATETIME DEFAULT GETDATE(),
    EventType NVARCHAR(50) NOT NULL,
    Description NVARCHAR(255) NOT NULL,
    Severity NVARCHAR(20) DEFAULT 'INFO' -- 'INFO', 'WARNING', 'ERROR'
);
GO