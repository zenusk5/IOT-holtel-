USE HotelIoT;
GO

IF OBJECT_ID('dbo.DeviceLogs', 'U') IS NOT NULL DROP TABLE dbo.DeviceLogs;
GO

CREATE TABLE dbo.DeviceLogs (
    LogId BIGINT IDENTITY(1,1) PRIMARY KEY,
    DeviceName NVARCHAR(50) NOT NULL,    -- 'DOOR_SERVO', 'ROOF_SERVO', 'LED_WS2812'
    Action NVARCHAR(50) NOT NULL,        -- 'OPEN', 'CLOSED', 'ON', 'OFF'
    TriggerSource NVARCHAR(50) NOT NULL, -- 'CSHARP_APP', 'WEB_APP', 'BLE', 'RFID_CARD', 'RAIN_SENSOR', 'AUTO_TIMEOUT'
    Details NVARCHAR(255) NULL,
    LogTime DATETIME DEFAULT GETDATE()
);
GO

CREATE NONCLUSTERED INDEX IX_DeviceLogs_LogTime ON dbo.DeviceLogs(LogTime DESC);
CREATE NONCLUSTERED INDEX IX_DeviceLogs_Device ON dbo.DeviceLogs(DeviceName);
GO