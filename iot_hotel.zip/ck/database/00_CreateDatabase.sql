IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'HotelIoT')
BEGIN
    CREATE DATABASE HotelIoT;
END
GO