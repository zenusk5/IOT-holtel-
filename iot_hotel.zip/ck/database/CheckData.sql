USE HotelIoT;
GO

-- [1] Xem trạng thái phòng hiện tại
SELECT * FROM dbo.DeviceStatus;

-- [2] Xem 5 lượt quẹt thẻ mới nhất
SELECT TOP 5 LogId, AccessTime, UID, AccessStatus, Notes 
FROM dbo.RFIDLogs 
ORDER BY LogId DESC;

-- [3] Xem 5 thao tác thiết bị mới nhất (Servo & LED)
SELECT TOP 5 LogId, LogTime, DeviceName, Action, TriggerSource, Details 
FROM dbo.DeviceLogs 
ORDER BY LogId DESC;

-- [4] Xem danh sách thẻ hợp lệ
SELECT CardId, UID, CardHolder, IsActive, CardType 
FROM dbo.RFIDCards;

-- [5] Xem 5 sự kiện hệ thống gần nhất
SELECT TOP 5 EventId, EventTime, EventType, Description, Severity 
FROM dbo.SystemEvents 
ORDER BY EventId DESC;